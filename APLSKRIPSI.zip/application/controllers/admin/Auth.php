<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends Admin {

	public function index()
	{
		$x['auth'] = $this->model->getalldtAdmin();
		adminSidebar();
		content('auth/vauth',$x);
		adminFooter();
		content('auth/script');
	}
	public function add()
	{
		adminSidebar();
		content('auth/insert');
		adminFooter();
		content('auth/script');	
	}
	public function edit($authID)
	{
		// $x['auth'] = $this->model->getdtAdminByAuthID($authID);
		// adminSidebar();
		// content('auth/edit',$x);
		// adminFooter();
		// content('auth/script');

		$config['upload_path'] = 'assets/upload/avatar';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
		$config['max_size']  = '15000'; //15MB
		$config['encrypt_name']  = true; //hashing file name
		
		$this->load->library('upload', $config);
		
		if ($this->upload->do_upload('avatar-edit-auth')){

			if (!is_null($this->session->userdata('avatar')) || !empty($this->session->userdata('avatar'))) {
				unlink('assets/upload/avatar/'.$this->session->userdata('avatar'));
			}

			$avatar = $this->upload->data('file_name');
		}
		else{
			$avatar = $this->session->userdata('avatar');
		}

		$data = [
			'avatar' => $avatar,
			'name' => $this->input->post('name-edit-auth'),
			'username' => $this->input->post('username-edit-auth'),
			'level' => $this->input->post('level-edit-auth'),
		];


		$db = $this->db->update('tbl_auth', $data, ['auth_id' => $authID]);

		if ($db == 1) {
			
			$this->session->set_userdata($data);
			
			$this->session->set_flashdata('msg','berhasil Edit data admin..');
			$this->session->set_flashdata('icon','success');
		}else{
			$this->session->set_flashdata('msg','gagal Edit data admin!, coba kembali');
			$this->session->set_flashdata('icon','error');
		}	
	}
	public function insert()
	{
		$config['upload_path'] = 'assets/upload/avatar';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
		$config['max_size']  = '15000'; //15MB
		$config['encrypt_name']  = true; //Encrypt Name
		
		$this->load->library('upload', $config);
		
		if ($this->upload->do_upload('avatar-add-auth')){
			$avatar = $this->upload->data('file_name');
		}else{
			$avatar = '';
		}

		$data = [
			'auth_id' 		=> rand(),
			'name' 	 		=> $this->input->post('nama-add-auth'),
			'username' 	 	=> $this->input->post('username-add-auth'),
			'password' 	 	=> password_hash($this->input->post('password-add-auth'), PASSWORD_DEFAULT),
			'avatar' 	 	=> $avatar,
			'create_at' 	=> date('y/m/d H:i:s'),
			'level' 	 	=> $this->input->post('level-add-auth')
		];

		$db = $this->db->insert('tbl_auth', $data);

		if ($db == 1) {
			$this->session->set_flashdata('msg','berhasil tambah data admin..');
			$this->session->set_flashdata('icon','success');
		}else{
			$this->session->set_flashdata('msg','gagal tambah data admin!, coba kembali');
			$this->session->set_flashdata('icon','error');
		}
	}
	public function delete($authID,$avatar=null)
	{
		if ($avatar) {
			unlink('assets/upload/avatar/'.$avatar);
		}

		$db = $this->db->where('auth_id',$authID)->delete('tbl_auth');

		if ($db == 1) {
			$this->session->set_flashdata('msg','berhasil Hapus data admin..');
			$this->session->set_flashdata('icon','success');
		}else{
			$this->session->set_flashdata('msg','gagal Hapus data admin!, coba kembali');
			$this->session->set_flashdata('icon','error');
		}
		redirect('admin/auth');
	}
	public function ubahpwdauth($authID)
	{
		$password_lama = $this->input->post('password-auth-lama');
		$password_baru = $this->input->post('password-auth-baru');

		if (password_verify($password_lama, $this->session->userdata('password'))) {
			
			$data = ['password' => password_hash($password_baru, PASSWORD_DEFAULT)];

			$db = $this->db->update('tbl_auth', $data, ['auth_id' => $authID]);

			if ($db == 1) {

				$this->session->set_userdata($data);

				$this->session->set_flashdata('icon','success');
				$this->session->set_flashdata('msg','berhasil Ubah Password admin..');
			}else{
				$this->session->set_flashdata('icon','error');
				$this->session->set_flashdata('msg','gagal Ubah Password admin!, coba kembali');
			}
		}else{

			$this->session->set_flashdata('icon','warning');
			$this->session->set_flashdata('msg','password lama salah!, coba kembali.');

		}
	}

}

/* End of file auth.php */
/* Location: ./application/controllers/admin/auth.php */