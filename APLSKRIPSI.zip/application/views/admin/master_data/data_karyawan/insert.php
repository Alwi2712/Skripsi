<div class="page-content">
    <div class="container-fluid">
        <form kar="insert" method="POST" action="<?= base_url();?>admin/master_data/insert_kar" enctype="multipart/form-data">
            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Tambah Data Karyawan</h4>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="text-right">
                        <a href="<?= base_url();?>admin/master_data/data_karyawan" class="btn btn-outline-danger mb-2"> Kembali </a>
                        <button type="submit" class="btn btn-outline-success mb-2 btn-f-kar"> Tambah </button>
                    </div>
                </div>
            </div>     
            <!-- end page title -->
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="text-center my-3">
                                <label>
                                    <input type="file" name="foto-add-kar" id="foto-add-kar" style="display:none;">
                                    <img style="height:140px;width:140px;" src="<?= base_url();?>assets/document/user.jpg" class="img-thumbnail" alt="Foto Karyawan">
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="form-group">
                                <label for="nama-add-kar">Nama Karyawan</label>
                                <input type="text" id="nama-add-kar" name="nama-add-kar" placeholder="Ketikan Nama .." class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="nik-add-kar">NIK Karyawan</label>
                                <input type="text"  minlength="6" maxlength="6" id="nik-add-kar" name="nik-add-kar" placeholder="Ketikan Nik, min 6 Karakter, max 6 Karakter" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="jk-add-kar">Jenis Kelamin</label>
                                <select name="jk-add-kar" id="jk-add-kar" class="form-control" required>
                                    <option value=""> -- pilih jenis kelamin -- </option>
                                    <option value="Laki-Laki"> Laki-Laki </option>
                                    <option value="Perempuan"> Perempuan </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="email-add-kar">Email</label>
                                <input type="email" id="email-add-kar" name="email-add-kar" placeholder="Ketikan Email .." class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="phone-num-add-kar">No Hp/WA</label>
                                <input type="number" id="phone-num-add-kar" name="phone-num-add-kar" placeholder="Ketikan No HP/WA .." class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="jab-add-kar">Pekerjaan Karyawan</label>
                                <select name="pek-add-kar" id="pek-add-kar" class="form-control" required>
                                    <option value=""> --pilih opsi pekerjaan-- </option>
                                    <?php foreach ($pek as $p): ?>
                                        <option value="<?= $p['pek_id'];?>"><?= $p['pekerjaan'];?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="jab-add-kar">Jabatan Karyawan</label>
                                <select name="jab-add-kar" id="jab-add-kar" class="form-control" required>
                                    <option value=""> --pilih opsi jabatan-- </option>
                                    <?php foreach ($jab as $j): ?>
                                        <option value="<?= $j['jabatan_id'];?>"><?= $j['jabatan'];?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->