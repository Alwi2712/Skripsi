<div class="container">
	
	<div class="row align-items-center">
		<div class="col-sm-12">
			<div class="page-title-box">
				<h4 class="font-size-18">HALAMAN PULANG </h4>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-xl-6 col-md-6">
			<div class="card mini-stat bg-danger text-white">
				<div class="card-body">
					<div class="mb-4">
						<div class="float-left mini-stat-img mr-4">
							<i class="mdi mdi-calendar mdi-36px"></i>
						</div>
						<h5 class="font-size-16 text-uppercase mt-0 text-white-50"> Tanggal </h5>
						<h4 class="font-weight-medium font-size-24"> <?= date('d/m/Y'); ?> </h4>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-6 col-md-6">
			<div class="card mini-stat bg-warning text-white">
				<div class="card-body">
					<div class="mb-4">
						<div class="float-left mini-stat-img mr-4">
							<i class="mdi mdi-clock mdi-36px"></i>
						</div>
						<h5 class="font-size-16 text-uppercase mt-0 text-white-50"> Jam </h5>
						<h4 class="font-weight-medium font-size-24"> <span class="times"></span> </h4>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="form-group">
		<div class="input-group">
            <div class="input-group-prepend">
                <a class="input-group-btn btn btn-info btn-lg" href="javascript:0" data-toggle="modal" data-target="#m-qrnik-scanner">
                	<i class="mdi mdi-qrcode"></i> <small>QRNIK</small>
                </a>
            </div>
			<input id="i-pulang-abs" type="text" class="form-control form-control-lg" placeholder="Masukan NIK Anda..">
        </div><!-- input-group -->
	</div>
</div>