<table id="table-absensi" class="table table-bordered table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>NAMA</th>
			<th>EMAIL</th>
			<th>TANGGAL</th>
			<th>JAM</th>
			<th>STATUS</th>
		</tr>
	</thead>
	<?php if (empty($absensi)){ ?>
		<tbody>
			<tr class="text-center">
				<th colspan="6"> Data kosong.. </th>
			</tr>
		</tbody>
	<?php }else{ ?>
		<tbody>
			<?php $no=1; foreach ($absensi as $row){ 
					if ($row['status']=='Masuk') {
						$status = '<span class="badge badge-pill badge-success"> Masuk </span>';
					} else if ($row['status']=='Pulang') {
						$status = '<span class="badge badge-pill badge-danger"> Pulang </span>';
					}else{
						$status = $row['status'];
					}
				?>
			<tr>
				<th> <?= $no++; ?> </th>
				<th> <?= $row['nama']; ?> </th>
				<th> <?= $row['email']; ?> </th>
				<th> <?= date('d F Y',strtotime($row['tgl'])); ?> </th>
				<th> <?= date('H:i:s',strtotime($row['tgl'])); ?> </th>
				<th> <?= $status; ?> </th>
			</tr>
			<?php } ?>
		</tbody>
	<?php } ?>
</table>
<script>
	$('table#table-absensi').DataTable();
</script>