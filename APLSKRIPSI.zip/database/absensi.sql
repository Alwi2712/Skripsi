-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 14, 2022 at 06:11 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `absensi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_absensi`
--

CREATE TABLE `tbl_absensi` (
  `absensi_id` varchar(65) NOT NULL,
  `nik` varchar(75) NOT NULL,
  `tgl` datetime NOT NULL,
  `status` enum('Masuk','Pulang','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_absensi`
--

INSERT INTO `tbl_absensi` (`absensi_id`, `nik`, `tgl`, `status`) VALUES
('1283324967', '777777', '2022-01-15 00:00:28', 'Masuk'),
('1767141130', '888888', '2022-01-14 00:00:00', 'Masuk'),
('1886822874', '888888', '2022-01-14 00:00:00', 'Pulang'),
('823536731', '777777', '2022-01-15 00:01:02', 'Pulang');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_auth`
--

CREATE TABLE `tbl_auth` (
  `auth_id` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(89) NOT NULL,
  `password` varchar(100) NOT NULL,
  `avatar` varchar(75) NOT NULL,
  `create_at` datetime NOT NULL,
  `level` enum('admin','karyawan','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_auth`
--

INSERT INTO `tbl_auth` (`auth_id`, `name`, `username`, `password`, `avatar`, `create_at`, `level`) VALUES
('917325039', 'Admin Dashboard', 'admin', '$2y$10$Kk76.2fyA3bFn2MRJo0ijODMAIWL6QiGVzGUitYosNF1HmzUK7Byy', '7f227325fd083280d659d67c3e6b323b.jpg', '2021-09-22 03:06:48', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jabatan`
--

CREATE TABLE `tbl_jabatan` (
  `jabatan_id` int(11) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_jabatan`
--

INSERT INTO `tbl_jabatan` (`jabatan_id`, `jabatan`, `create_at`) VALUES
(1, 'Resepsionis', '2021-09-22 03:16:27'),
(2, 'Kepala Dinas', '2021-09-22 03:17:07'),
(3, 'Sender', '2021-09-22 03:17:14'),
(9, 'Senior', '2021-12-16 21:53:10'),
(10, 'Junior', '2021-12-16 21:53:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_karyawan`
--

CREATE TABLE `tbl_karyawan` (
  `karyawan_id` varchar(95) NOT NULL,
  `jabatan_id` int(15) DEFAULT NULL,
  `pek_id` int(15) DEFAULT NULL,
  `nik` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kel` enum('Laki-Laki','Perempuan','') NOT NULL,
  `email` varchar(75) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `create_at` datetime NOT NULL,
  `foto` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_karyawan`
--

INSERT INTO `tbl_karyawan` (`karyawan_id`, `jabatan_id`, `pek_id`, `nik`, `nama`, `jenis_kel`, `email`, `phone_number`, `create_at`, `foto`) VALUES
('1139731176', 9, 6, '877777', 'Solehudin Skheh', 'Laki-Laki', 'solehudin@gmail.com', '6232736726', '2022-01-14 23:51:46', NULL),
('1256764487', 10, 6, '677833', 'Putri Utami', 'Perempuan', 'putri@gmail.com', '622837237', '2022-01-14 23:51:46', NULL),
('1683292093', 9, 4, '123555', 'Ahmed Salehudin', 'Laki-Laki', 'AhmedSalehudin@gmail.com', '77627366', '2022-01-14 23:51:46', NULL),
('1909598552', 10, 6, '443233', 'Anisa Ulfah', 'Perempuan', 'anisaUl@gmail.com', '6228372873', '2022-01-15 00:40:56', ''),
('437457997', 9, 3, '555555', 'Albert johnson', 'Laki-Laki', 'suryaman@gmail.com', '12312333333', '2022-01-14 23:49:43', 'c3d33ccd5ef7e99ca59ae8bb1e92c8e2.jpg'),
('530921757', 9, 4, '888888', 'Khoer Komarudin', 'Laki-Laki', 'KhoerKomar@gmail.com', '62632372637', '2022-01-14 23:51:46', NULL),
('569747957', 10, 4, '817234', 'suryaman albertson', 'Laki-Laki', 'suryaman@gmail.com', '35345345', '2022-01-14 23:49:29', 'e0275d2e744568afe45ed42f0601de19.jpg'),
('578059575', 10, 3, '777777', 'Junjun Chumaru', 'Laki-Laki', 'JunjunChu@gmail.com', '628812372', '2022-01-14 23:51:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pekerjaan`
--

CREATE TABLE `tbl_pekerjaan` (
  `pek_id` int(11) NOT NULL,
  `pekerjaan` char(150) NOT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_pekerjaan`
--

INSERT INTO `tbl_pekerjaan` (`pek_id`, `pekerjaan`, `create_at`) VALUES
(1, 'Polisi Kemiliteran', '2021-12-16 21:39:42'),
(2, 'Politikus Ekonomi', '2021-12-16 21:40:00'),
(3, 'Programmer Mobile Dev', '2021-12-16 21:40:28'),
(4, 'Programmer Web Dev', '2021-12-16 21:40:55'),
(6, 'Dokter', '2022-01-14 23:51:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_absensi`
--
ALTER TABLE `tbl_absensi`
  ADD PRIMARY KEY (`absensi_id`),
  ADD KEY `nik` (`nik`);

--
-- Indexes for table `tbl_auth`
--
ALTER TABLE `tbl_auth`
  ADD PRIMARY KEY (`auth_id`);

--
-- Indexes for table `tbl_jabatan`
--
ALTER TABLE `tbl_jabatan`
  ADD PRIMARY KEY (`jabatan_id`);

--
-- Indexes for table `tbl_karyawan`
--
ALTER TABLE `tbl_karyawan`
  ADD PRIMARY KEY (`karyawan_id`),
  ADD KEY `jabatan_id` (`jabatan_id`),
  ADD KEY `pekerjaan_id` (`pek_id`);

--
-- Indexes for table `tbl_pekerjaan`
--
ALTER TABLE `tbl_pekerjaan`
  ADD PRIMARY KEY (`pek_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_jabatan`
--
ALTER TABLE `tbl_jabatan`
  MODIFY `jabatan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_pekerjaan`
--
ALTER TABLE `tbl_pekerjaan`
  MODIFY `pek_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
