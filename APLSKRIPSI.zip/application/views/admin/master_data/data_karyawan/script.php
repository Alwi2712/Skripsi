<script>
	(function(t) {	

		'use strict';

		var table_kar = t('#table-kar');
		var ObjTableImport = t('#obj-content-timportExc table tbody');
		var cno = 90;
		var qrnikGenerate = document.getElementById('generate-qrnik');
		var btn_download_QRnik = document.getElementById('btn-download-qrnik');
		
		t('form[kar]').parsley();

		/* Initialize QRGenerate */
			var qrnik = new QRCode(qrnikGenerate, {
			    colorDark : "#000000",
			    colorLight : "#ffffff",
			    correctLevel : QRCode.CorrectLevel.H
			});
		/* End QRGenerate */

		table_kar.DataTable({
			lengthChange:!1,
			buttons:[
	            {extend:'copy',className:'btn btn-sm btn-secondary mr-2 button-exp-tables'},
	            {extend:'excel',className:'btn btn-sm btn-success mr-2 button-exp-tables',text:'Export Excel'},
	            {extend:'pdf',className:'btn btn-sm btn-danger mr-2 button-exp-tables',text:'Export PDF'},
				{extend:'csv',className:'btn btn-sm btn-info mr-2 button-exp-tables',text:'Export CSV'},
	            {extend:'print',className:'btn btn-sm btn-warning mr-2 button-exp-tables'},
	            {extend:'colvis',className:'btn btn-primary btn-sm mr-2 button-exp-tables',text:'Kolom Visibility'}
			]
		})
		.buttons()
		.container()
		.appendTo('#table-kar_wrapper .col-md-6:eq(0)');

		t('form[kar]').submit(function(){

			if ('form[kar="insert"]'){
				var btnTxt = 'Tambah';
			} else if ('form[kar="edit"]'){
				var btnTxt = 'Edit';
			}

			if (t('form[kar] input[type="text"]').val() =='' || t('form[kar] input[type="email"]').val() == ''){
				return false;
			}else{
				t.ajax({
					url:t(this).attr('action'),
					type:'POST',
					data:new FormData(this),
					cache:false,
					contentType:false,
					processData:false,
					beforeSend:function(res){
						t('form[kar] button.btn-f-kar').html('<i class="mdi mdi-loading mdi-spin"></i>').prop('disabled',true);
					}
				})
				.done(res => {
					t('form[kar] button.btn-f-kar').html(btnTxt).removeAttr('disabled');
					window.location.href=baseurl+'admin/master_data/data_karyawan';
					console.log('success insert data..');
				})
				.catch(err => {
					t('form[kar] button.btn-f-kar').html(btnTxt).removeAttr('disabled');
					console.log('error insert data..');
				});
			}
			
			return false;
		});

		t('button.btn-addColumn-import').click((e) => {
			cno += 1;
			t.ajax({
				type:'post',
				url:baseurl+'admin/master_data/karAddColumnImportExc',
				data:{cno:cno},
				cache:false
			})
			.done(response => {
				console.log(response);
				t(ObjTableImport).append(response);
			})
			.catch(err => {
				console.log(err);
			})
		});

		t('#obj-content-timportExc table').on('click','.btn-remove-columnKar',function(){
			let tkid = t(this).attr('tkid');
			t('#obj-content-timportExc table tbody tr.tk_'+tkid).remove();

			if(t('#obj-content-timportExc table tbody tr.tkid').text()){
				t('button.btn-addColumn-import').show();
			}else{
				t(ObjTableImport).html(`<tr><td colspan="8" class="text-center p-3"> baris kosong.. </td></tr>`);
				t('#import-excel-karyawan').val('');
				t('button.btn-addColumn-import').hide();
			}
		});

		t('#import-excel-karyawan').on('change',function(event){
			
			let ObjTableImport = t('#obj-content-timportExc table tbody');
			let fileExt = t(this).val().split('.').pop();

			if (fileExt.startsWith('xls') || fileExt.startsWith('xlsx') || fileExt.startsWith('csv')) {
				renderReadExcel(ObjTableImport, event);
			}else{
				Swal.fire('','ekstensi tidak diperbolehkan!, hanya support ekstensi [.xls/.xlsx/.csv]','warning');
				t(this).val('');
			}

		});

		t('form[importKar]').submit(function(){
			if(!t('#obj-content-timportExc table tbody tr.tkid').text()){
				Swal.fire({
					title:'',
					text:'kolom tabel kosong!',
					type:'warning',
					width:300
				});
				return false;
			}
		})

		t('#ctx-all-kar').change(function(){
			if(t(this).is(':checked')){
				t('#btn-delete-ctx-kar').show();
				t('.ctx-column-kar').prop('checked',true);
			}else{
				t('#btn-delete-ctx-kar').hide();
				t('.ctx-column-kar').prop('checked',false);
			}
		});

		table_kar.on('change','.ctx-column-kar',function(){

			let ctx_kar=[];

			t('.ctx-column-kar:checked').each((id) => {
				ctx_kar[id] = t(this).val();
			});

			if(ctx_kar.length > 0){
				t('#btn-delete-ctx-kar').show();
			}else{
				t('#btn-delete-ctx-kar').hide();
			}
		});

		t('#btn-delete-ctx-kar').click(function(){

			var ctx_kar = [];

			t('.ctx-column-kar:checked').each(function(id){
				ctx_kar[id] = t(this).val();
			});

			Swal.fire({
				title:'anda yakin?',
				type:'warning',
				text:`akan hapus ${ctx_kar.length} data karyawan!`,
				showCancelButton: true,
	            confirmButtonColor: '#3085d6',
	            cancelButtonColor: '#d33',
	            confirmButtonText: 'Oke',
	            cancelButtonText: 'Batal!',
	            width:350
	        })
	        .then(res => {
	        	if(res.value){
	        		t.ajax({
	        			type:'POST',
	        			url:baseurl+'admin/master_data/delete_ctxKar',
	        			data:{ kar_id:ctx_kar },
	        			cache:false
	        		})
	        		.done(res => {
	        			console.log(res);
	        			window.location.reload();
	        		})
	        		.catch(err => {
	        			console.log(err);
	        		})
	        	}
	        })
		});

		table_kar.on('click','.btn-qrnik-kar', function(){
			
			let nik = t(this).attr('nik');
			let nama = t(this).attr('nama_kar');

			qrnik.makeCode(nik);

			t('#m-qrnik').modal('show');

			download_QrNik(nik, nama + '.png');
		});

		function download_QrNik(nik, fileName) {
			
			qrnik.makeCode(nik);

			setTimeout(() => {
				let qrEl = document.querySelector('#generate-qrnik img');
				let qrn = qrEl.getAttribute('src');
				btn_download_QRnik.setAttribute('href', qrn);
				btn_download_QRnik.setAttribute('download', fileName);
			});
		}

		function renderReadExcel(ObjTableImport, event) {
			
			var file = event.target.files[0];
			var reader = new FileReader();
			var nik=[], nama=[], email=[], noHp=[], pekerjaan=[], jabatan=[], jenis_kel=[]

			reader.onload = function(event){
				var data = event.target.result;
				var wb = XLSX.read(data, {type:'binary'});

				wb.SheetNames.forEach(function(sheetname) {
					var XLRowObj = XLSX.utils.sheet_to_row_object_array(wb.Sheets[sheetname]);

					// setelah upload terbaca sesuaikan dengan title tabel
					for (var i = 0; i < XLRowObj.length; i++) {
						nik.push(XLRowObj[i]['NIK']);
						nama.push(XLRowObj[i]['NAMA']);
						email.push(XLRowObj[i]['EMAIL']);
						noHp.push(XLRowObj[i]['NO HP']);
						pekerjaan.push(XLRowObj[i]['PEKERJAAN']);
						jabatan.push(XLRowObj[i]['JABATAN']);
						jenis_kel.push(XLRowObj[i]['JENIS KELAMIN']);
					}

					t.ajax({
						type:'post',
						url:baseurl+'admin/master_data/importExcKar',
						cache:false,
						data:{
							nik:nik,
							nama:nama,
							email:email,
							noHp:noHp,
							pekerjaan:pekerjaan,
							jabatan:jabatan,
							jenis_kel:jenis_kel
						}
					})
					.done(response => {
						console.log(response);
						t(ObjTableImport).html(response);
						t('button.btn-addColumn-import').show();
						t('#info-status-impExc').fadeIn('slow').html('<span class="badge badge-success"> berhasil import data excell..</span>');
					})
					.catch(err => {
						console.log(err)
						t('#info-status-impExc').fadeIn('slow').html('<span class="badge badge-danger"> gagal import data excell!</span>');
					});

					setTimeout(function(){
						t('#info-status-impExc').slideUp('slow');
					},2500);
				})
			}

			reader.onerror = function(exc) {
				console.log(exc);
			}

			reader.readAsBinaryString(file);

		}

	}($));
</script>