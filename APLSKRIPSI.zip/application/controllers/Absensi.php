<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Absensi extends CI_Controller {

	public function index()
	{
		$this->load->view('index/absensi');
		$this->load->view('index/popup_qrscanner');
		$this->load->view('index/script');
	}
	public function masuk()
	{
		$this->load->view('index/masuk');
		$this->load->view('index/popup_qrscanner');
		$this->load->view('index/script');
	}
	public function pulang()
	{
		$this->load->view('index/pulang');
		$this->load->view('index/popup_qrscanner');
		$this->load->view('index/script');
	}
	public function kehadiran()
	{
		$status = $this->input->post('status');
		$input = $this->input->post('input');

		if (isset($status)) {
			
			$this->model->absensi($status, $input);
		
		}else{
			echo 'null';
		}
	}
	public function getAbsByNik($nik=null)
	{
		$status = 'Absensi';

		if (isset($nik)) {

			$Abs = $this->model->absensi($status, $nik);

			if ($Abs == true){
				
				$data['absensi'] = $Abs;
				$json['data'] = $this->load->view('index/t_absensi', $data, TRUE);
				// $json['data_status'] = 200;
			}else{
				$data['absensi'] = '';
				$json['data'] = $this->load->view('index/t_absensi', $data, TRUE);
				// $json['data_status'] = 404;

				$json['msg_title'] = 'alert!';
				$json['msg_info'] = 'error';
				$json['msg_txt'] = 'Nik Tidak Ditemukan!';	
			}

			echo json_encode($json);
		}else{
			echo 'null';
		}
	}

}

/* End of file Absensi.php */
/* Location: ./application/controllers/Absensi.php */