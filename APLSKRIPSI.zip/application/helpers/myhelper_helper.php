<?php 

function ci()
{
	return get_instance();
}
function is_logged()
{
	if(empty(ci()->session->userdata('auth_id')) || ci()->session->userdata('auth_id')==''){
		redirect('admin/login','refresh');
	}
}
function adminSidebar()
{
	ci()->load->view('admin/layout/head-sidebar');
}
function content($p=null,$d=[],$i=null)
{
	ci()->load->view('admin/'.$p,$d,$i);
}
function adminFooter()
{
	ci()->load->view('admin/layout/footer');
}