<script type="text/javascript">
	(function(t) {
		'use strict';

		var table_abs = t('#table-absensi');
	var btn_delete_ctxAbs_list = t('#btn-delete-ctxAbs');

	table_abs.DataTable({
		lengthChange:!1,
		buttons:[
	        {extend:'copy',className:'btn btn-sm btn-secondary mr-2 button-exp-tables'},
	        {extend:'excel',className:'btn btn-sm btn-success mr-2 button-exp-tables',text:'Export Excel'},
	        {extend:'pdf',className:'btn btn-sm btn-danger mr-2 button-exp-tables',text:'Export PDF'},
			{extend:'csv',className:'btn btn-sm btn-info mr-2 button-exp-tables',text:'Export CSV'},
	        {extend:'print',className:'btn btn-sm btn-warning mr-2 button-exp-tables'},
	        {extend:'colvis',className:'btn btn-primary btn-sm mr-2 button-exp-tables',text:'Kolom Visibility'}
		]
	})
	.buttons()
	.container()
	.appendTo('#table-absensi_wrapper .col-md-6:eq(0)');

	var ctx_abs_all = t('#ctx-abs-all');

	ctx_abs_all.change(function(){
		t('input.ctx-abs-').not(this).prop('checked',this.checked);
	})

	table_abs.on('change','.input.ctx-abs-',(e) => {

	});

	btn_delete_ctxAbs_list.click(function(e){
		
		var ctx_absid=[]

		t('input.ctx-abs-:checked').each(function(id){ ctx_absid[id] = t(this).val() })

		if (ctx_absid.length > 0) {
			Swal.fire({
				title:'anda yakin?',
				type:'warning',
				text:`akan hapus ${ctx_absid.length} data absensi!`,
				showCancelButton: true,
	            confirmButtonColor: '#3085d6',
	            cancelButtonColor: '#d33',
	            confirmButtonText: 'Oke',
	            cancelButtonText: 'Batal!',
	            width:350
	        })
	        .then(res => {
	        	if (res.value){
	        		t.post(baseurl+'admin/absensi/deleteList?post=200',{
	        			absid:ctx_absid,
	        			countAbsid:ctx_absid.length
	        		})
	        		.done(result => {
	        			window.location.reload();
	        		})
	        		.catch(err => {
	        			console.log(err);
	        			Swal.fire({
							title:'',
							text:'gagal delete absensi!',
							type:'error',
							width:350
						});			
	        		})
	        	}
	        })
		}else{
			Swal.fire({
				title:'',
				text:'centang salah satu data untuk delete!',
				type:'warning',
				width:350
			});
		}
	});

}($));
</script>