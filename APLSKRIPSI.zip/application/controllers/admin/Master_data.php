<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master_data extends Admin {

	public function data_karyawan()
	{
		$x['karyawan'] = $this->model->getalldtKar();
		adminSidebar();
		content('master_data/data_karyawan/vdata_karyawan',$x);
		adminFooter();
		content('master_data/data_karyawan/script');
	}
	public function data_jabatan()
	{
		$x['jab'] = $this->model->getalldtJab();
		adminSidebar();
		content('master_data/jabatan/vjabatan',$x);
		adminFooter();
		content('master_data/jabatan/script');
	}
	public function data_pekerjaan()
	{
		$x['pekerjaan'] = $this->model->getalldtPekrj();
		adminSidebar();
		content('master_data/pekerjaan/vpekerjaan',$x);
		adminFooter();
		content('master_data/pekerjaan/script');
	}
	public function add_karyawan()
	{
		$x['jab'] = $this->model->getalldtJab();
		$x['pek'] = $this->model->getalldtPekrj();
		adminSidebar();
		content('master_data/data_karyawan/insert',$x);
		adminFooter();
		content('master_data/data_karyawan/script');
	}
	public function edit_karyawan($karID)
	{
		$x['pek'] = $this->model->getalldtPekrj();
		$x['jab'] = $this->model->getalldtJab();
		$x['kar'] = $this->model->getKarByid($karID);
		adminSidebar();
		content('master_data/data_karyawan/edit',$x);
		adminFooter();
		content('master_data/data_karyawan/script');
	}
/*== crud pekerjaan ==*/
	public function insert_edit_pek()
	{
		$pekID = $this->input->post('data-pek-id');

		if ($pekID=='' || empty($pekID)) {
			
			$data = [
				'pekerjaan' => $this->input->post('pekerjaan-data'),
				'create_at' => date('y/m/d H:i:s')
			];

			$db = $this->db->insert('tbl_pekerjaan', $data);

			if ($db == 1){
				$this->session->set_flashdata('icon','success');
				$this->session->set_flashdata('msg','berhasil tambah data pekerjaan..');
			}else{
				$this->session->set_flashdata('icon','error');
				$this->session->set_flashdata('msg','gagal tambah data pekerjaan!, coba kembali.');
			}
		}else{
			
			$data = [
				'pekerjaan' => $this->input->post('pekerjaan-data')];

			$db = $this->db->update('tbl_pekerjaan', $data, ['pek_id'=>$pekID]);
			
			if ($db == 1){
				$this->session->set_flashdata('icon','success');
				$this->session->set_flashdata('msg','berhasil edit data pekerjaan..');
			}else{
				$this->session->set_flashdata('icon','error');
				$this->session->set_flashdata('msg','gagal edit data pekerjaan!, coba kembali.');
			}
		}
		redirect('admin/master_data/data_pekerjaan');				
	}
	public function delete_pekerjaan($pekID)
	{
		$db = $this->db->delete('tbl_pekerjaan', ['pek_id'=>$pekID]);

		if ($db == 1){
			$this->session->set_flashdata('icon','success');
			$this->session->set_flashdata('msg','berhasil hapus data pekerjaan..');
		}else{
			$this->session->set_flashdata('icon','error');
			$this->session->set_flashdata('msg','gagal hapus data pekerjaan!, coba kembali.');
		}
		redirect('admin/master_data/data_pekerjaan');
	}

/*== crud jabatan ==*/
	public function insert_edit_jab()
	{
		$jabID = $this->input->post('data-jabatan-id');

		if ($jabID=='' || empty($jabID)) {
			
			$data = [
				'jabatan' => $this->input->post('jabatan-data'),
				'create_at' => date('y/m/d H:i:s')
			];

			$db = $this->db->insert('tbl_jabatan', $data);

			if ($db == 1){
				$this->session->set_flashdata('icon','success');
				$this->session->set_flashdata('msg','berhasil tambah data jabatan..');
			}else{
				$this->session->set_flashdata('icon','error');
				$this->session->set_flashdata('msg','gagal tambah data jabatan!, coba kembali.');
			}
		}else{
			
			$data = [
				'jabatan' => $this->input->post('jabatan-data')];

			$db = $this->db->update('tbl_jabatan', $data, ['jabatan_id'=>$jabID]);
			
			if ($db == 1){
				$this->session->set_flashdata('icon','success');
				$this->session->set_flashdata('msg','berhasil edit data jabatan..');
			}else{
				$this->session->set_flashdata('icon','error');
				$this->session->set_flashdata('msg','gagal edit data jabatan!, coba kembali.');
			}
		}
		redirect('admin/master_data/data_jabatan');				
	}
	public function delete_jab($jabID)
	{
		$db = $this->db->delete('tbl_jabatan', ['jabatan_id'=>$jabID]);

		if ($db == 1){
			$this->session->set_flashdata('icon','success');
			$this->session->set_flashdata('msg','berhasil hapus data jabatan..');
		}else{
			$this->session->set_flashdata('icon','error');
			$this->session->set_flashdata('msg','gagal hapus data jabatan!, coba kembali.');
		}
		redirect('admin/master_data/data_jabatan');
	}
/*== crud data karyawan ==*/
	public function insert_kar()
	{
		$config['upload_path'] = 'assets/upload/karyawan';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
		$config['max_size']  = '15000'; //15MB
		$config['encrypt_name']  = true; //random file name
		
		$this->load->library('upload', $config);
		
		if ($this->upload->do_upload('foto-add-kar')){
			$foto = $this->upload->data('file_name');
		}else{
			$foto = '';
		}

		$data = [
			'karyawan_id' => rand(),
			'nik' 	=> $this->input->post('nik-add-kar'),
			'nama' 	=> $this->input->post('nama-add-kar'),
			'email' 	=> $this->input->post('email-add-kar'),
			'jenis_kel' => $this->input->post('jk-add-kar'),
			'phone_number' 	=> $this->input->post('phone-num-add-kar'),
			'create_at' 	=> date('y/m/d H:i:s'),
			'foto' 	=> $foto,
			'pek_id' 	=> $this->input->post('pek-add-kar'),
			'jabatan_id' 	=> $this->input->post('jab-add-kar')
		];

		$db = $this->db->insert('tbl_karyawan', $data);

		if ($db == true) {
			$this->session->set_flashdata('icon','success');
			$this->session->set_flashdata('msg','berhasil tambah data karyawan..');
		}else{
			$this->session->set_flashdata('icon','error');
			$this->session->set_flashdata('msg','gagal tambah data karyawan!, coba kembali.');
		}
	}
	public function edit_kar($karID)
	{
		$config['upload_path'] = 'assets/upload/karyawan';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
		$config['max_size']  = '15000'; //15MB
		$config['encrypt_name']  = true; //random file name
		
		$foto_lama = $this->input->post('foto-lama-edit-kar');

		$this->load->library('upload', $config);
		
		if ($this->upload->do_upload('foto-edit-kar')){

			if ($foto_lama!='' || $foto_lama!=null) {
				unlink('assets/upload/karyawan');
			}

			$foto = $this->upload->data('file_name');
		}else{
			$foto = $foto_lama;
		}

		$data = [
			'nik' 	=> $this->input->post('nik-edit-kar'),
			'nama' 	=> $this->input->post('nama-edit-kar'),
			'email' 	=> $this->input->post('email-edit-kar'),
			'jenis_kel' => $this->input->post('jk-edit-kar'),
			'phone_number' 	=> $this->input->post('phone-num-edit-kar'),
			'create_at' 	=> date('y/m/d H:i:s'),
			'foto' 	=> $foto,
			'pek_id' 	=> $this->input->post('pek-edit-kar'),
			'jabatan_id' 	=> $this->input->post('jab-edit-kar')
		];

		$db = $this->db->update('tbl_karyawan', $data, ['karyawan_id'=>$karID]);

		if ($db == true) {
			$this->session->set_flashdata('icon','success');
			$this->session->set_flashdata('msg','berhasil Edit data karyawan..');
		}else{
			$this->session->set_flashdata('icon','error');
			$this->session->set_flashdata('msg','gagal Edit data karyawan!, coba kembali.');
		}
	}
	// public function delete_kar($karID)
	// {
	// 	$kar = $this->model->getKarByid($karID);

	// 	if (isset($kar['foto'])) {
	// 		unlink('assets/upload/karyawan/'.$kar['foto']);
	// 	}

	// 	$db = $this->db->delete('tbl_karyawan',['karyawan_id'=>$karID]);

	// 	if ($db == 1) {
	// 		$this->session->set_flashdata('icon','success');
	// 		$this->session->set_flashdata('msg','berhasil hapus data karyawan..');
	// 	}else{
	// 		$this->session->set_flashdata('icon','error');
	// 		$this->session->set_flashdata('msg','gagal hapus data karyawan!, coba kembali.');
	// 	}
	// 	redirect('admin/master_data/data_karyawan');
	// }
	public function importExcKar()
	{
		$pekerjaan = $this->model->getalldtPekrj();
		$jabatan = $this->model->getalldtJab();
		$columnNo=0;
		$tbody = '';


		foreach ($_POST['nik'] as $key => $value) {

			$pek_val = $_POST['pekerjaan'][$key];
			$jab_val = $_POST['jabatan'][$key];
			$jk_val = $_POST['jenis_kel'][$key];

			if($jk_val=='Laki-Laki'){ $attrSelectJk1 = 'selected';}else{$attrSelectJk1='';}
			if($jk_val=='Perempuan'){ $attrSelectJk2 = 'selected';}else{$attrSelectJk2='';}

			$tbody .= '<tr class="tk_'.$columnNo.' tkid">';
			$tbody .= '<td><input type="text" name="nik_i[]" title="'.$_POST['nik'][$key].'" minlength="6" maxlength="6" class="form-control" value="'.$_POST['nik'][$key].'" placeholder="min 6 baris, max 6 baris." required></td>';
			$tbody .= '<td><input type="text" name="nama_i[]" title="'.$_POST['nama'][$key].'" class="form-control" placeholder="isikan nama karyawan. " value="'.$_POST['nama'][$key].'" required /></td>';
			$tbody .= '<td><input type="email" name="email_i[]" title="'.$_POST['email'][$key].'" class="form-control" placeholder="isikan email karyawan.. " value="'.$_POST['email'][$key].'" required /></td>';
			$tbody .= '<td><input type="number" name="noHp_i[]" title="'.$_POST['noHp'][$key].'" class="form-control" value="'.$_POST['noHp'][$key].'" placeholder="isikan No Hp.." required /></td>';
			$tbody .= '<td>';
			$tbody .= '<select class="form-control" name="pek_i[]" title="'.$pek_val.'" required>
						<option> -- pilih jenis pekerjaan -- </option>';
					foreach ($pekerjaan as $row) {
						if ($row['pekerjaan'] === $pek_val) {
					$tbody .= '<option selected value="'.$row['pek_id'].'"> '.$row['pekerjaan'].' </option>';
						}else{
					$tbody .= '<option value="'.$row['pek_id'].'"> '.$row['pekerjaan'].' </option>';
						}
					}
			$tbody .= '</select>
					</td>';
			$tbody .= '<td>';
			$tbody .= '<select class="form-control" name="jab_i[]" title="'.$jab_val.'" required><option> -- pilih jenis jabatan -- </option>';
					foreach ($jabatan as $row2) {
						if ($row2['jabatan'] === $jab_val) {
					$tbody .= '<option selected value="'.$row2['jabatan_id'].'"> '.$row2['jabatan'].' </option>';
						}else{
					$tbody .= '<option value="'.$row2['jabatan_id'].'"> '.$row2['jabatan'].' </option>';
						}
					}
			$tbody .= '</select>
					</td>';
			$tbody .= '<td><select class="form-control" name="jk_i[]" title="'.$jk_val.'" required><option value=""> -- pilih jenis kelamin -- </option><option '.$attrSelectJk1.' value="Laki-Laki"> Laki-Laki </option><option '.$attrSelectJk2.' value="Perempuan"> Perempuan </option></td>';
			$tbody .= '<td><a href="javascript:void(0)" tkid="'.$columnNo.'" class="btn btn-danger btn-sm btn-remove-columnKar"> &times;</a></td>';
			$tbody .= '</tr>';

			$columnNo++;
		}

		echo $tbody;
	}
	public function karAddColumnImportExc()
	{
		$pekerjaan = $this->model->getalldtPekrj();
		$jabatan = $this->model->getalldtJab();
		$columnNo = $this->input->post('cno');
		$tbody = '';

		$tbody .= '<tr class="tk_'.$columnNo.' tkid">';
			$tbody .= '<td><input type="text" name="nik_i[]" minlength="6" maxlength="6" class="form-control" placeholder="min 6 baris, max 6 baris." required></td>';
			$tbody .= '<td><input type="text" name="nama_i[]" class="form-control" placeholder="isikan nama karyawan. " required /></td>';
			$tbody .= '<td><input type="email" name="email_i[]" class="form-control" placeholder="isikan email karyawan.. " required /></td>';
			$tbody .= '<td><input type="number" name="noHp_i[]" class="form-control" placeholder="isikan No Hp.." required /></td>';
			$tbody .= '<td>';
			$tbody .= '<select class="form-control" name="pek_i[]" required>
					<option> -- pilih jenis pekerjaan -- </option>';
					foreach ($pekerjaan as $row) {
			$tbody .= '<option value="'.$row['pekerjaan'].'"> '.$row['pekerjaan'].' </option>';
					}
			$tbody .= '</select>
					</td>';
			$tbody .= '<td>';
			$tbody .= '<select class="form-control" name="jab_i[]" required>
						<option> -- pilih jenis jabatan -- </option>';
					foreach ($jabatan as $row2) {
			$tbody .= '<option value="'.$row2['jabatan'].'"> '.$row2['jabatan'].' </option>';
					}
			$tbody .= '</select>
					</td>';
			$tbody .= '<td><select class="form-control" name="jk_i[]" required><option value=""> -- pilih jenis kelamin -- </option></select></td>';
			$tbody .= '<td><a href="javascript:void(0)" tkid="'.$columnNo.'" class="btn btn-danger btn-sm btn-remove-columnKar"> &times;</a></td>';
			$tbody .= '</tr>';

		echo $tbody;
	}
	public function processSubmitImportExc()
	{
		if (isset($_POST)) {
			
			$data=[];

			foreach ($_POST['nik_i'] as $key => $value) {
				$data[] = [
					'karyawan_id' => rand(),
					'nik' 	  	=> $_POST['nik_i'][$key],
					'nama' 	  	=> $_POST['nama_i'][$key],
					'email' 	  	=> $_POST['email_i'][$key],
					'phone_number' 	  => $_POST['noHp_i'][$key],
					'pek_id'		=> $_POST['pek_i'][$key],
					'jabatan_id'	  => $_POST['jab_i'][$key],
					'jenis_kel'	  => $_POST['jk_i'][$key],
					'create_at'	 => date('y/m/d H:i:s')];
			}

			$db = $this->db->insert_batch('tbl_karyawan', $data);

			if ($db == true) {
				$this->session->set_flashdata('icon','success');
				$this->session->set_flashdata('msg','berhasil import data karyawan..');
			}else{
				$this->session->set_flashdata('icon','error');
				$this->session->set_flashdata('msg','gagal import data karyawan!, coba kembali.');
			}

			redirect('admin/master_data/data_karyawan');
		}else{
			$var = 'error post data form!';
			print_r($var);
		}
	}
	public function delete_ctxKar()
	{
		$kar_id = $this->input->post('kar_id');
		
		if (isset($kar_id)) {
			
			$karyawan = $this->model->getKarIdMultiple($kar_id);

			foreach ($karyawan as $kr) {
				if (isset($kr['foto'])) {
					unlink('./assets/upload/karyawan/'.$kr['foto']);
				}
			}

			$db = $this->db->where_in('karyawan_id',$kar_id)->delete('tbl_karyawan');

			if ($db == 1) {
				$this->session->set_flashdata('icon','success');
				$this->session->set_flashdata('msg','berhasil hapus '.count($karyawan).' data karyawan..');
			}else{
				$this->session->set_flashdata('icon','error');
				$this->session->set_flashdata('msg','gagal hapus data karyawan!, coba kembali.');
			}

		}else{
			$db = 0;
			echo 'error karyawan id empty/null!';
		}

		echo $db;
	}

}

/* End of file master_data.php */
/* Location: ./application/controllers/admin/master_data.php */