<script>
	(function($) {

		$('form[jab]').parsley();

		var table_jab = $('#table-jabatan');

		table_jab.DataTable();

		table_jab.on('click','.btn-delete-jab',function(e){
			
			let jabID = $(this).attr('jabID');

			myconfirm()

				.then(res => {
					if (res.value){
						window.location.href=baseurl+'admin/master_data/delete_jab/'+jabID;
					}
				})
		});

		table_jab.on('click','.btn-edit-jab',function(){
			
			let jabID = $(this).attr('jabID');
			let jab = $(this).attr('jab');
			
			$('#f-jabatan .card-header')
			.removeClass('bg-success')
			.addClass('bg-primary')
			
			$('#f-jabatan form .btn-jab-act')
			.html('<i class="mdi mdi-pencil"></i> Jabatan')
			.removeClass('btn-outline-success')
			.addClass('btn-outline-primary')

			$('#f-jabatan .btn-reset-act')
			.show()

			$('#data-jabatan-id').val(jabID);
			$('#jabatan-data').val(jab);
		});

		$('#f-jabatan .btn-reset-act').click(function(){
			$('#f-jabatan .card-header')
			.removeClass('bg-primary')
			.addClass('bg-success')

			$('#f-jabatan form .btn-jab-act')
			.html('<i class="mdi mdi-plus"></i> Jabatan')
			.removeClass('btn-outline-primary')
			.addClass('btn-outline-success')

			$('#f-jabatan .btn-reset-act')
			.hide()

			$('#data-jabatan-id').val('');
			$('#jabatan-data').val('');
		});

	}(jQuery));
</script>