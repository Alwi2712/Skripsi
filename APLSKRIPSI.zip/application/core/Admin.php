<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		is_logged(); // <= helper function
	}

}

// Public Controller

/* End of file Admin.php */
/* Location: ./application/core/Admin.php */