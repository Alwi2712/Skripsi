<div class="page-content">
    <div class="container-fluid">
        <form auth="insert" action="<?= base_url();?>admin/auth/insert" enctype="multipart/form-data">
            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Tambah Data Admin</h4>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="text-right">
                        <a href="<?= base_url();?>admin/auth" class="btn btn-outline-danger mb-2"> Kembali </a>
                        <button type="submit" class="btn btn-outline-success mb-2 btn-f-auth"> Tambah </button>
                    </div>
                </div>
            </div>     
            <!-- end page title -->
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="text-center my-3">
                                <label>
                                    <input type="file" name="avatar-add-auth" id="avatar-add-auth" style="display:none;">
                                    <img style="height:150px;width:150px;" src="<?= base_url();?>assets/document/user.jpg" class="img-thumbnail" alt="avatar auth admin">
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="form-group">
                                <label for="nama-add-auth">Nama Admin</label>
                                <input type="text" id="nama-add-auth" name="nama-add-auth" placeholder="Ketikan Nama .." class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="username-add-auth">Username</label>
                                <input type="text" id="username-add-auth" name="username-add-auth" placeholder="Ketikan Username untuk login .." class="form-control" required>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="password-add-auth">Password</label>
                                <input type="password" id="password-add-auth" name="password-add-auth" placeholder="Ketikan Password untuk login .." class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="cpassword-add-auth">Password konfirmasi</label>
                                <input type="password" data-parsley-equalto="#password-add-auth" id="cpassword-add-auth" name="password-add-auth" placeholder="Ketikan Password Ulang, yang sama .." class="form-control" required>
                            </div>
                            <div class="my-2">
                                <label>
                                    <input id="show-pwd" type="checkbox"> Lihat Password 
                                </label>
                            </div>
                            <div class="form-group">
                                <label for="level-add-auth">Level Hak akses</label>
                                <select name="level-add-auth" id="level-add-auth" class="form-control" required>
                                    <option value=""> --pilih level-- </option>
                                    <option value="Admin"> Admin </option>
                                    <option value="Karyawan"> Karyawan </option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->