<script type="text/javascript">
	$(function(){
		
		$('form[auth]').parsley();

		var table_admin = $('#table-auth');

		table_admin.DataTable();

		$('#show-pwd').on('change',function(){
			if ($(this).is(':checked')) {
				$('#password-add-auth').prop('type','text');
				$('#cpassword-add-auth').prop('type','text');
			} else {
				$('#password-add-auth').prop('type','password');
				$('#cpassword-add-auth').prop('type','password');
			}
		});

		$('#avatar-add-auth').change(function(res){
			let source = URL.createObjectURL(res.target.files[0]);
			$(this).next('img').attr('src',source);
		});

		$('form[auth]').submit(function(e){

			if($('input[type="file"]').val()==''){
				Swal.fire('','Avatar Anda Kosong!','warning');
			}else{
				$.ajax({
					url:$(this).attr('action'),
					type:'POST',
					data:new FormData(this),
					cache:false,
					processData:false,
					contentType:false,
					beforeSend:function(res){
						$('form[auth] button.btn-f-auth').html('<i class="mdi mdi-loading mdi-spin"></i>').prop('disabled',true);
					}
				})
				.done(res => {
					$('form[auth] button.btn-f-auth').html('Tambah').removeAttr('disabled');
					window.location.href=baseurl+'admin/auth';
					console.log('success insert data..');
				})
				.catch(err => {
					$('form[auth] button.btn-f-auth').html('Tambah').removeAttr('disabled');
					console.log('error insert data..');
				});
			}

			return false;
		});

		table_admin.on('click','.btn-delete-auth',function(){

			var authID = $(this).attr('authID');
			var avatar = $(this).attr('avatar');

			myconfirm()
			.then(r => {
				if (r.value){
					window.location.href=baseurl+'admin/auth/delete/'+authID+'/'+avatar;
				}
			})
		});

	}(jQuery));
</script>