<div class="page-content">
    <div class="container-fluid">
        <form auth="insert" action="<?= base_url();?>admin/auth/update" enctype="multipart/form-data">
            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Edit Data Admin</h4>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="text-right">
                        <a href="<?= base_url();?>admin/auth" class="btn btn-outline-danger mb-2"> Kembali </a>
                        <button type="submit" class="btn btn-outline-primary mb-2 btn-f-auth"> Update </button>
                    </div>
                </div>
            </div>     
            <!-- end page title -->
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="text-center my-3">
                                <label>
                                    <input type="file" name="avatar-edit-auth" id="avatar-edit-auth" style="display:none;">
                                    <img style="height:150px;width:150px;" src="<?= base_url();?>assets/document/user.jpg" class="img-thumbnail" alt="avatar auth admin">
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="form-group">
                                <label for="nama-edit-auth">Nama Admin</label>
                                <input type="text" id="nama-edit-auth" name="nama-edit-auth" placeholder="Ketikan Nama .." value="<?= $auth['name'];?>" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="username-edit-auth">Username</label>
                                <input type="text" id="username-edit-auth" name="username-edit-auth" placeholder="Ketikan Username untuk login .." value="<?= $auth['username'];?>" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="level-add-auth">Level Hak akses</label>
                                <select name="level-add-auth" id="level-add-auth" class="form-control" required>
                                    <option value=""> --pilih level-- </option>
                                    <option value="Admin" <?php if($auth['level']=='admin'){echo 'selected';}?>> Admin </option>
                                    <option value="Karyawan" <?php if($auth['level']=='karyawan'){echo 'selected';}?>> Karyawan </option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->