<script>
	(function(t){
		
		'use strict';

		var t_main_abs = t('#t-main-absensi');
		var btn_qr_play = t('#btn-play-qrnik');
		var btn_qr_upload = t('#btn-upload-qrnik');
		var btn_qr_stop = t('#btn-stop-qrnik');
		var qr_scanner = t('#qrnik-scanner');
		var qr_selectCamera = t('#qrnik-select-camera');
		var qr_scanTargetOutput = t('input[type="text"]');
		var msg_qr_success = t('.msg-qrnik-success');
		var msg_qr_error = t('.msg-qrnik-error');

		var option = {
			beep:baseurl+'assets/QRCameraJs/audio/beep.mp3',
			height:350,
			width:400,
			resultFunction:(result) => { resultQrScanner(result) }
		}

		var QRNik = qr_scanner.WebCodeCamJQuery(option).data().plugin_WebCodeCamJQuery;

		QRNik.buildSelectMenu(qr_selectCamera,"environment|back");

		btn_qr_play.click(() => QRNik.play());
		btn_qr_upload.click(() => QRNik.play().decodeLocalImage());
		btn_qr_stop.click(() => QRNik.stop());
		
		qr_selectCamera.change(() => {if (QRNik.isInitialized())QRNik.stop().play()})

		function resultQrScanner(result){
			if (result.code) {
				qr_scanTargetOutput.val(result.code);
				msg_qr_success.fadeIn('slow').animate({bottom:0},3000,function(){
					setTimeout(function(){
						msg_qr_success.fadeOut('slow');
					},2500);
				})
			}else{
				msg_qr_error.fadeIn('slow').animate({bottom:0},3000,function(){
					setTimeout(function(){
						msg_qr_error.fadeOut('slow');
					},2500);
				})
			}
		}

		function myAlert(title='', text, icon) {
			return Swal.fire({
				title:title,
				text:text,
				type:icon,
				width:350
			});
		}

		t('input[type="text"]').keyup(function(event){
			
			var input_id = t(this).attr('id');

			if (input_id=='i-masuk-abs') {
				var statusMenu = 'Masuk';	
			} else if (input_id=='i-pulang-abs') {
				var statusMenu = 'Pulang';
			}else if (input_id=='i-absensi'){
				var statusMenu = 'Absensi';
			}else{var statusMenu = '';}

			if (event.keyCode===13) {

				if (t(this).val() === '') {
				
					myAlert('required','isikan nik anda!!','warning');
				
				} else if (t(this).val().length < 6) {
				
					myAlert('min length!','minimal nilai untuk nik, 6 baris..','warning');
				
				} else if (t(this).val().length > 6) {
				
					myAlert('max length!','maksimal nilai untuk nik, 6 baris..','warning');
				
				} else if (statusMenu==='Masuk'||statusMenu==='Pulang') {

					t.post(baseurl+'Absensi/kehadiran',{
						input:t(this).val(),
						status:statusMenu
					})
					.done(res => {
						let data = JSON.parse(res);
						console.log(data);
						if(data.msg_info=='success'){
							t('input#'+input_id).val('');
						}
						myAlert(data.msg_title, data.msg_txt, data.msg_info);
					})
					.catch(err => {
						myAlert('alert!','Gagal Melakukan Absensi! '+statusMenu+', Coba Kembali','error');
						console.log(err)
					})
				} else {

					if(statusMenu=='Absensi'){ tMainContent(t(this).val()) }
				
				}

			}else{

				if(statusMenu=='Absensi'){ tMainContent(t(this).val()) }
			}
		});

		/*  get times  */
		getTimes()
		function getTimes(){
			let timesNow=new Date()
			let h=timesNow.getHours()
			let m=timesNow.getMinutes()
			let s=timesNow.getSeconds()
			
			m=cekTimes(m)
			s=cekTimes(s)
			
			t('span.times').html(h+':'+m+':'+s);

			setTimeout(function(){
				getTimes();
			},500)
		}
		function cekTimes(t) {
			if (t<10){ t='0'+t} return t;
		}

		if (window.location.hash.replace('#/','')==='absensi') {
			tMainContent();
		}

		function tMainContent(nik=null) {
			t.post(baseurl+'Absensi/getAbsByNik/'+nik)
			.done(res => {
				let results = JSON.parse(res);
				// if (results.data_status==404) {
				// 	myAlert(results.msg_title, results.msg_txt, results.msg_info);
				// }
				t_main_abs.html(results.data);
					console.log(results.data);
				})
			.catch(err => {
				// myAlert('alert!','Gagal Melakukan Ambil Data Absensi!, Coba Kembali','error');
				console.log(err)
			})
		}

	}($));
</script>