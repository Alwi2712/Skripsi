<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model extends CI_Model {

/*Load Database tbl_auth*/
	public function getalldtAdmin()
	{
		$this->db->select('*');
		$this->db->from('tbl_auth');
		$this->db->order_by('create_at', 'desc');
		return $this->db->get()->result_array();
	}
	public function getdtAdminByAuthID($authID)
	{
		$this->db->select('*');
		$this->db->from('tbl_auth');
		$this->db->where('auth_id', $authID);
		return $this->db->get()->row_array();
	}

/*Load Database tbl_jabatan*/
	public function getalldtJab()
	{
		$this->db->select('*');
		$this->db->from('tbl_jabatan');
		$this->db->order_by('create_at', 'desc');
		return $this->db->get()->result_array();
	}

/*Load Database tbl_pekerjaan*/
	public function getalldtPekrj()
	{
		$this->db->select('*');
		$this->db->from('tbl_pekerjaan');
		$this->db->order_by('create_at', 'desc');
		return $this->db->get()->result_array();
	}

/*Load Database tbl_karyawan*/
	public function getalldtKar()
	{
		$this->db->select('*');
		$this->db->from('tbl_karyawan k');
		$this->db->join('tbl_jabatan j', 'j.jabatan_id = k.jabatan_id', 'left');
		$this->db->join('tbl_pekerjaan p', 'p.pek_id = k.pek_id', 'left');
		$this->db->order_by('k.create_at', 'desc');
		return $this->db->get()->result_array();
	}
	public function getKarByid($karID)
	{
		return $this->db->get_where('tbl_karyawan',['karyawan_id'=>$karID])->row_array();
	}
	public function getKarIdMultiple($karid)
	{
		return $this->db->where_in('karyawan_id',$karid)->get('tbl_karyawan')->result_array();
	}
/*Database tbl_absensi*/
	public function getalldtAbsensi()
	{
		$query = $this->db->select('*')
				->from('tbl_absensi a')
				->join('tbl_karyawan k','k.nik = a.nik','left')
				->join('tbl_pekerjaan p','p.pek_id = k.pek_id','left')
				->join('tbl_jabatan j','j.jabatan_id = k.jabatan_id','left')
				->order_by('nama','desc')
				->order_by('tgl','desc')
				->get();
		return $query->result_array();
	}
	public function absensi($status, $input)
	{
		if ($status=='Absensi') {
			return $this->getalldtAbsByNik($input);
		}else{
			return$this->check_absensi($status, $input);
		}
	}
	public function getalldtAbsByNik($input)
	{
		$query = $this->db->select('*')
		->from('tbl_absensi a')
		->where('a.nik',$input)
		->where("(status='Masuk' || status='Pulang')")
		->join('tbl_karyawan k', 'k.nik = a.nik', 'left')
		->order_by('tgl', 'desc')
		->get();
		return $query->result_array();
	}
	public function check_absensi($status, $input)
	{
		date_default_timezone_set('Asia/Jakarta');

		$dateNow = date('y-m-d');
		$dateTimeNow = date('y-m-d H:i:s');
		$cekNik = $this->db->where('nik', $input)
							->get_where('tbl_karyawan')->row();
		$cekAbs = $this->db->where('nik', $input)
							->where('status', $status)
							->where('DATE(tgl)',$dateNow)
							->get('tbl_absensi')->num_rows();

		if ($cekNik == true) {
			
			if ($cekAbs > 0) {
				$json['msg_title'] = $cekNik->nama;
				$json['msg_info'] = 'warning';
				$json['msg_txt'] = 'Anda Baru Saja Melakukan Absensi '.$status . ' Hari ini.';	
			}else{
				$db_info = $this->db->insert('tbl_absensi', [
					'absensi_id' => rand(),
					'nik' 	=> $input,
					'tgl' => $dateTimeNow,
					'status' => $status
				]);

				if ($db_info==1) {
					$json['msg_title'] = $cekNik->nama;
					$json['msg_info'] = 'success';
					$json['msg_txt'] = 'Berhasil melakukan kehadiran '.$status;
				}else{
					$json['msg_title'] = $cekNik->nama;
					$json['msg_info'] = 'error';
					$json['msg_txt'] = 'Gagal Melakukan Absensi '.$status .', coba kembali!';
				}
			}
		}else{
			$json['msg_title'] = 'alert!';
			$json['msg_info'] = 'error';
			$json['msg_txt'] = 'Nik Tidak Ditemukan!';
			
		}
		echo json_encode($json);
	}
	public function deleteAbsList($abs_id, $cAbsid)
	{
		$db = $this->db->where_in('absensi_id',$abs_id)->delete('tbl_absensi');

		if ($db == 1) {
			$this->session->set_flashdata('msg','berhasil delete '.$cAbsid.' data absensi..');
			$this->session->set_flashdata('icon','success');
		}else{
			$this->session->set_flashdata('msg','gagal delete '.$cAbsid.' data absensi!, coba kembali');
			$this->session->set_flashdata('icon','error');
		}
	}
}

/* End of file model.php */
/* Location: ./application/models/model.php */