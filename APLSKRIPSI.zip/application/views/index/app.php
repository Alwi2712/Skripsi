<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title> MASUK | ABSENSI MANAGEMENT</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Management Absensi Karyawan.." name="description" />
    <meta content="Buildercorp" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?= base_url('assets/document');?>/favicon.ico">
    <!-- chart -->
    <link href="<?= base_url('assets');?>/libs/chartist/chartist.min.css" rel="stylesheet">
    <!-- Sweet Alert-->
    <link href="<?= base_url('assets');?>/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />   
    <!-- Bootstrap Css -->
    <link href="<?= base_url('assets');?>/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- DataTables -->
    <link href="<?= base_url('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css');?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?= base_url('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css');?>" rel="stylesheet" type="text/css" />  
    <!-- Icons Css -->
    <link href="<?= base_url('assets/css/icons.min.css');?>" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?= base_url('assets/css/app.min.css');?>" id="app-style" rel="stylesheet" type="text/css" />


    <style>
        .button-exp-tables{
            border-radius:0;
        }
        #qrnik-scanner{
            border-radius:5px;
            background-color:#cecece;
            height:350px;
            width:100%;
        }
        .qr-line{
            position: absolute;
            margin: 35px;
            height: 40px;
            width: 40px;
        }
        .line-rb{
            opacity:0.5;
            bottom: 0;
            right: 0;
            border-bottom: solid red 2px;
            border-right: solid red 2px;
        }
        .line-rt{
            opacity:0.5;
            top: 0;
            right: 0;
            border-top: solid red 2px;
            border-right: solid red 2px;
        }
        .line-lb{
            opacity:0.5;
            bottom: 0;
            left: 0;
            border-bottom: solid red 2px;
            border-left: solid red 2px;
        }
        .line-lt{
            opacity:0.5;
            top: 0;
            left: 0;
            border-top: solid red 2px;
            border-left: solid red 2px;
        }
    </style>
</head>

<body data-sidebar="light">

    <div id="app">

        <!-- Begin page -->
        <div id="layout-wrapper">

            <header id="page-topbar">
                <div class="navbar-header">
                    <div class="d-flex">
                        <!-- LOGO -->
                        <div class="navbar-brand-box">
                            <a href="<?= base_url();?>" class="logo logo-dark">
                                <span class="logo-sm text-dark">
                                    <img src="<?= base_url('assets/document/favicon.ico'); ?>" alt="" height="22">
                                </span>
                                <span class="logo-lg text-dark">
                                    <!-- <img class="mb-2" src="<?= base_url('assets/upload/avatar/'.$this->session->userdata('avatar')); ?>" alt="" height="35"> -->
                                    <span> ABSENSI</span>
                                </span>
                            </a>

                            <a href="<?= base_url();?>" class="logo logo-light text-white">
                                <span class="logo-sm">
                                    <img src="<?= base_url('assets/document/favicon.ico'); ?>" alt="" height="22">
                                </span>
                                <span class="logo-lg">
                                    <!-- <img class="mb-2" src="<?= base_url('assets/document/favicon.ico'); ?>" alt="" height="35"> -->
                                    <span> ABSENSI</span>
                                </span>
                            </a>
                        </div>

                        <button type="button" class="btn btn-sm px-3 font-size-24 header-item waves-effect" id="vertical-menu-btn">
                            <i class="mdi mdi-menu"></i>
                        </button>
                    </div>

                    <div class="d-flex">

                        <div class="dropdown d-none d-lg-inline-block">
                            <button type="button" class="btn header-item noti-icon waves-effect" data-toggle="fullscreen">
                                <i class="mdi mdi-fullscreen"></i>
                            </button>
                        </div>

                        <div class="dropdown d-inline-block">
                            <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="rounded-circle header-profile-user" src="<?= base_url('assets/document/user.jpg');?>"
                            alt="Login Dashboard">
                        </button>
                        <div class="dropdown-menu dropdown-menu-right">
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-danger" href="<?= base_url('admin/login');?>"><i class="bx bx-power-off font-size-17 align-middle mr-1 text-danger"></i> Login Dashboard</a>
                        </div>
                    </div>

                </div>
            </div>
        </header>

        <!-- ========== Left Sidebar Start ========== -->
        <div class="vertical-menu">

            <div data-simplebar class="h-100">

                <!--- Sidemenu -->
                <div id="sidebar-menu">
                    <!-- Left Menu Start -->
                    <ul class="metismenu list-unstyled" id="side-menu">
                        <li class="menu-title">Main</li>

                        <li class="masuk">
                            <a href="/masuk" class="waves-effect masuk">
                                <i class="mdi mdi-door-open text-success"></i>
                                <span>Masuk</span>
                            </a>
                        </li>
                        <li class="pulang">
                            <a href="/pulang" class="waves-effect pulang">
                                <i class="mdi mdi-door-closed text-danger"></i>
                                <span>Pulang</span>
                            </a>
                        </li>
                        <li class="absensi">
                            <a href="/absensi" class="waves-effect absensi">
                                <i class="mdi mdi-calendar text-info"></i>
                                <span>Absensi</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- Sidebar -->
            </div>
        </div>
        <!-- Left Sidebar End -->

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">

                    <div id="result-main"></div>
                    
                </div><!-- container-fluid -->
            </div>
            <!-- End Page-content -->

            <!-- note: script footer di hapus tampilan gk rapih -->
            <?= $this->config->item('footer');?>
        </div>
        <!-- end main content-->
    </div>

    <!-- JAVASCRIPT -->
    <script src="<?= base_url('assets');?>/libs/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets');?>/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url('assets');?>/libs/metismenu/metisMenu.min.js"></script>
    <script src="<?= base_url('assets');?>/libs/simplebar/simplebar.min.js"></script>
    <script src="<?= base_url('assets');?>/libs/node-waves/waves.min.js"></script>
    <!-- Required datatable js -->
    <script src="<?= base_url('assets');?>/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?= base_url('assets');?>/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <!-- Responsive examples -->
    <script src="<?= base_url('assets');?>/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?= base_url('assets');?>/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
    <!-- Plugin Js-->
    <!-- Sweet Alerts js -->
    <script src="<?= base_url('assets');?>/libs/sweetalert2/sweetalert2.min.js"></script>
    <!-- Peity chart-->
    <script src="<?= base_url('assets');?>/libs/peity/jquery.peity.min.js"></script>
    <script>var baseurl="<?= base_url();?>"</script>
    <script src="<?= base_url('assets');?>/js/app.js"></script>
    <script src="<?= base_url('assets');?>/js/menu.js"></script>
    <!-- QRCodeCameraJs -->
    <script src="<?= base_url('assets/QRCameraJs/');?>js/qrcodelib.js"></script>
    <script src="<?= base_url('assets/QRCameraJs/');?>js/filereader.js"></script>
    <script src="<?= base_url('assets/QRCameraJs/');?>js/webcodecamjquery.js"></script>
</body>

</html>