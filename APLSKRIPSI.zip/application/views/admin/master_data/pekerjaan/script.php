<script>
	$(document).ready(function(){
		
		'use strict';

		var table_pek = $('#table-pekerjaan');

		table_pek.DataTable();

		table_pek.on('click','.btn-delete-pek',function(e){
			
			let pekID = $(this).attr('pekID');

			myconfirm()

				.then(res => {
					if (res.value){
						window.location.href=baseurl+'admin/master_data/delete_pekerjaan/'+pekID;
					}
				})
		});

		table_pek.on('click','.btn-edit-pek',function(){
			
			let pekID = $(this).attr('pekID');
			let pekerjaan = $(this).attr('pek');
			
			$('#f-pek .card-header')
			.removeClass('bg-success')
			.addClass('bg-primary')
			
			$('#f-pek form .btn-pek-act')
			.html('<i class="mdi mdi-pencil"></i> Pekerjaan')
			.removeClass('btn-outline-success')
			.addClass('btn-outline-primary')

			$('#f-pek .btn-reset-act')
			.show()

			$('#data-pek-id').val(pekID);
			$('#pekerjaan-data').val(pekerjaan);
		});

		$('#f-pek .btn-reset-act').click(function(){
			$('#f-pek .card-header')
			.removeClass('bg-primary')
			.addClass('bg-success')

			$('#f-pek form .btn-pek-act')
			.html('<i class="mdi mdi-plus"></i> Pekerjaan')
			.removeClass('btn-outline-primary')
			.addClass('btn-outline-success')

			$('#f-pek .btn-reset-act')
			.hide()

			$('#data-pek-id').val('');
			$('#pekerjaan-data').val('');
		});

		$('form[pek]').parsley();
	});
</script>