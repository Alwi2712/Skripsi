<div class="container">

	<div class="row align-items-center">
		<div class="col-sm-12">
			<div class="page-title-box">
				<h4 class="font-size-18">HALAMAN ABSENSI</h4>
			</div>
		</div>
	</div>

	<div class="form-group">
		<div class="input-group">
            <div class="input-group-prepend">
                <a class="input-group-btn btn btn-info btn-lg" href="javascript:0" data-toggle="modal" data-target="#m-qrnik-scanner">
                	<i class="mdi mdi-qrcode"></i> <small>QRNIK</small>
                </a>
            </div>
			<input id="i-absensi" type="text" class="form-control form-control-lg" placeholder="Masukan NIK Anda..">
        </div><!-- input-group -->
	</div>
	
	<div class="card">
		<div class="card-body">
			<div id="t-main-absensi" class="table-responsive"></div>
		</div>
	</div>
</div>