<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="page-title-box">
                    <h4 class="font-size-18">HALAMAN DATA KARYAWAN</h4>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="text-right">
                    <button id="btn-delete-ctx-kar" style="display:none;" class="btn btn-outline-danger mb-2"><i class="mdi mdi-delete"></i> Karyawan</button>
                    <button data-toggle="modal" data-target="#m-import-from-excel" class="btn btn-outline-info mb-2"><i class="mdi mdi-import"></i> Import Dari Excel</button>
                    <a href="<?= base_url('admin/master_data/add_karyawan');?>" class="btn btn-outline-success mb-2"><i class="mdi mdi-plus-circle"></i> Karyawan</a>
                </div>
            </div>
        </div>     
        <!-- end page title -->
        <div class="card">
            <div class="card-body">
                <div class="table-responsive w-100">
                    <table id="table-kar" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="ctx-all-kar"></th>
                                <th>FOTO</th>
                                <th>NIK</th>
                                <th>NAMA KARYAWAN</th>
                                <th>EMAIL</th>
                                <th>NO HP/WA</th>
                                <th>PEKERJAAN</th>
                                <th>JABATAN</th>
                                <th>TANGGAL INPUT</th>
                                <th>JENIS KELAMIN</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $sno=1; if (!empty($karyawan)){
                                foreach ($karyawan as $k){ ?>
                                <tr>
                                    <td><input class="ctx-column-kar" type="checkbox" value="<?= $k['karyawan_id'];?>"></td>
                                    <td>
                                        <?php if($k['foto']==''||is_null($k['foto'])){
                                            $source=base_url().'assets/document/user.jpg';
                                        }else{
                                            $source=base_url().'assets/upload/karyawan/'.$k['foto'];
                                        } ?>
                                        <img style="height:70px;width:70px;border-radius:5px;" src="<?= $source;?>" alt="">
                                    </td>
                                    <td><?= $k['nik']; ?></td>
                                    <td><?= $k['nama']; ?></td>
                                    <td><?= $k['email']; ?></td>
                                    <td><?= $k['phone_number']; ?></td>
                                    <td><?= $k['pekerjaan']; ?></td>
                                    <td><?= $k['jabatan']; ?></td>
                                    <td><?= date('d F Y',strtotime($k['create_at'])); ?></td>
                                    <td><?= $k['jenis_kel'] ?></td>
                                    <td>
                                        <a href="<?= base_url('admin/master_data/edit_karyawan/'.$k['karyawan_id']);?>" class="btn btn-outline-primary btn-edit-kar mb-2"> <i class="mdi mdi-pencil"></i> Edit</a>
                                        <button nik="<?= $k['nik']; ?>" nama_kar="<?= $k['nama']; ?>" class="btn btn-outline-info mb-2 btn-qrnik-kar" type="button"> <i class="mdi mdi-qrcode"></i> QRNik </button>
                                    </td>
                                </tr>
                                <?php } } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->

<!-- Modal Import Excell -->
<div class="modal fade" id="m-import-from-excel">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-body">
                <button class="close" data-dismiss="modal">x</button>
                <div class="form-group">
                    <label for="import-excel-karyawan">Import Excel</label>
                    <input type="file" id="import-excel-karyawan" class="form-control">
                    <small class="text-danger">support ekstensi : .xls/.xlsx/.csv</small>
                </div>

                <div class="mt-3">
                    <form importKar action="<?= base_url();?>admin/master_data/processSubmitImportExc" method="post" multiple>
                        <div class="table-responsive" id="obj-content-timportExc" style="overflow-y:auto;height:400px">
                            <div class="text-right" id="info-status-impExc"></div>
                            <table class="table table-bordered table-striped">
                                <thead class="bg-info text-white">
                                    <tr>
                                        <th>NIK</th>
                                        <th>NAMA</th>
                                        <th>EMAIL</th>
                                        <th>NO HP</th>
                                        <th>PEKERJAAN</th>
                                        <th>JABATAN</th>
                                        <th>JENIS KELAMIN</th>
                                        <th><i class="mdi mdi-settings"></i></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td colspan="8" class="text-center p-3"> BARIS KOSONG.. </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="text-right">
                                <button type="button" class="btn btn-success btn-sm btn-block btn-addColumn-import" style="display:none;"><i class="mdi mdi-plus-circle"></i> kolom table </button>
                            </div>
                        </div>
                        <small class="text-danger"><strong>catatan:</strong> sesuaikan kolom dari excel A1, B1, C1, D1 utk judul tabel sesuai diatas selain icon ( <i class="mdi mdi-settings"></i> ), hurup kapital semua!</small>
                        <div>
                            <button class="btn btn-info my-2" type="submit"> submit </button>
                            <button class="btn btn-danger my-2" type="button" data-dismiss="modal"> Tutup </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal QR Generate -->
<div class="modal fade" id="m-qrnik">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button class="close" data-dismiss="modal">x</button>
                <div class="text-center">
                    <div style="display:flex;justify-content:center;text-align:center;" id="generate-qrnik"></div>
                </div>
                <div class="text-center mt-3">
                    <a id="btn-download-qrnik" href="javascript:0" class="btn btn-info my-2"> Download QRNik </a>
                    <a href="javascript:0" data-dismiss="modal" class="btn btn-danger my-2"> Tutup Popup </a>
                </div>
            </div>
        </div>
    </div>
</div>