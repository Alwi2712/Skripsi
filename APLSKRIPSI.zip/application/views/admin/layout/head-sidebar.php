<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />

        <?php if ($this->uri->segment(2)=='master_data' && $this->uri->segment(3)=='data_karyawan' || $this->uri->segment(2)=='master_data' && $this->uri->segment(3)=='data_jabatan'){
            $title = strtoupper(str_replace('_', ' ', $this->uri->segment(3)));
        }else{
            $title = strtoupper(str_replace('_', ' ', $this->uri->segment(2)));
        } ?>

        <title> <?= $title; ?> | ABSENSI KARYAWAN</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Dashboard Management Absensi Karyawan.." name="description" />
        <meta content="Arby Saepul Ryzen" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?= base_url('assets/document');?>/favicon.ico">
        <!-- chart -->
        <link href="<?= base_url('assets');?>/libs/chartist/chartist.min.css" rel="stylesheet">
        <!-- DataTables -->
        <link href="<?= base_url('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css');?>" rel="stylesheet" type="text/css" />
        <link href="<?= base_url('assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css');?>" rel="stylesheet" type="text/css" />
        <!-- Sweet Alert-->
        <link href="<?= base_url('assets');?>/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
        <!-- Responsive datatable examples -->
        <link href="<?= base_url('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css');?>" rel="stylesheet" type="text/css" />    
        <!-- Bootstrap Css -->
        <link href="<?= base_url('assets');?>/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?= base_url('assets/css/icons.min.css');?>" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?= base_url('assets/css/app.min.css');?>" id="app-style" rel="stylesheet" type="text/css" />
        <style>
            .button-exp-tables{
                border-radius:0;
            }
        </style>
    </head>

    <body data-sidebar="dark">

        <!-- Begin page -->
        <div id="layout-wrapper">

            <header id="page-topbar">
                <div class="navbar-header">
                    <div class="d-flex">
                        <!-- LOGO -->
                        <div class="navbar-brand-box">
                            <a href="<?= base_url('admin/dashboard');?>" class="logo logo-dark">
                                <span class="logo-sm">
                                    <img src="<?= base_url('assets/document/favicon.ico'); ?>" alt="" height="22">
                                </span>
                                <span class="logo-lg">
                                    <span> <?= $this->config->item('app_name');?> </span>
                                </span>
                            </a>

                            <a href="<?= base_url('admin/dashboard');?>" class="logo logo-light text-white">
                                <span class="logo-sm">
                                    <img src="<?= base_url('assets/document/favicon.ico'); ?>" alt="" height="22">
                                </span>
                                <span class="logo-lg">
                                    <!-- <img class="mb-2" src="<?= base_url('assets/document/favicon.ico'); ?>" alt="" height="35"> -->
                                    <span> <?= $this->config->item('app_name');?> </span>
                                </span>
                            </a>
                        </div>

                        <button type="button" class="btn btn-sm px-3 font-size-24 header-item waves-effect" id="vertical-menu-btn">
                            <i class="mdi mdi-menu"></i>
                        </button>
                    </div>

                    <div class="d-flex">
                        <div class="dropdown d-none d-md-block ml-2">
                            <button type="button" class="btn header-item waves-effect"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                               <b>Hii!, <?= $this->session->userdata('name');?></b>
                            </button>
                        </div>

                        <div class="dropdown d-none d-lg-inline-block">
                            <button type="button" class="btn header-item noti-icon waves-effect" data-toggle="fullscreen">
                                <i class="mdi mdi-fullscreen"></i>
                            </button>
                        </div>

                        <div class="dropdown d-inline-block">
                            <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img class="rounded-circle header-profile-user" src="<?= base_url('assets/upload/avatar/'.$this->session->userdata('avatar'));?>"
                                    alt="<?= $this->session->userdata('name');?>">
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <!-- item-->
                                <a class="dropdown-item" href="javascript:void(0)" data-toggle="modal" data-target="#m-data-auth"><i class="mdi mdi-account-circle font-size-17 align-middle mr-1"></i> Profile</a>
                                <a class="dropdown-item" href="javascript:void(0)" data-toggle="modal" data-target="#m-pwdc-auth"><i class="mdi mdi-lock-outline font-size-17 align-middle mr-1"></i> Ubah Password</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="<?= base_url('admin/login/out');?>"><i class="bx bx-power-off font-size-17 align-middle mr-1 text-danger"></i> Logout</a>
                            </div>
                        </div>

                        <!-- <div class="dropdown d-inline-block">
                            <button type="button" class="btn header-item noti-icon right-bar-toggle waves-effect">
                                <i class="mdi mdi-settings-outline"></i>
                            </button>
                        </div> -->
            
                    </div>
                </div>
            </header>

            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title">Main</li>

                            <li>
                                <a href="<?= base_url('admin/dashboard');?>" class="waves-effect">
                                    <i class="ti-home"></i>
                                    <span>Dashboard</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?= base_url('admin/auth');?>" class="waves-effect">
                                    <i class="mdi mdi-account-key"></i>
                                    <span>Admin</span>
                                </a>
                            </li>

                            <li class="menu-title">Components</li>

                            <li class="<?php if($this->uri->segment(3)=='add_karyawan' || $this->uri->segment(3)=='edit_karyawan'){echo'mm-active';} ?>">
                                <a href="javascript:void(0)" class="has-arrow waves-effect <?php if($this->uri->segment(3)=='add_karyawan' || $this->uri->segment(3)=='edit_karyawan'){echo'mm-active';} ?>">
                                    <!-- <i class="mdi mdi-account-multiple-plus-outline"></i> -->
                                    <i class="ti-package"></i>
                                    <span>Master Data</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    <li><a href="<?= base_url('admin/master_data/data_pekerjaan');?>">Data Pekerjaan</a></li>
                                    <li><a href="<?= base_url('admin/master_data/data_jabatan');?>">Data Jabatan</a></li>
                                    <li class="<?php if($this->uri->segment(3)=='add_karyawan' || $this->uri->segment(3)=='edit_karyawan'){echo'mm-active';} ?>"><a class="<?php if($this->uri->segment(3)=='add_karyawan' || $this->uri->segment(3)=='edit_karyawan'){echo'mm-active';} ?>" href="<?= base_url('admin/master_data/data_karyawan');?>">Data Karyawan</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="<?= base_url('admin/absensi');?>" class="waves-effect">
                                    <i class="mdi mdi-calendar-check"></i>
                                    <span> Absensi </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->

            <div id="message-data" 
            msg="<?= $this->session->flashdata('msg');?>" 
            icon="<?= $this->session->flashdata('icon');?>"></div>

            <div class="main-content">