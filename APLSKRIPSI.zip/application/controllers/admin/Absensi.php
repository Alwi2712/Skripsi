<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Absensi extends CI_Controller {

	public function index()
	{
		$x['absensi'] = $this->model->getalldtAbsensi();
		adminSidebar();
		content('absensi/vabsensi',$x);
		adminFooter();
		content('absensi/script');
	}
	public function deleteList()
	{
		if (isset($_GET['post'])&&$_GET['post']==='200') {
			
			$abs_id = $this->input->post('absid');
			$cAbsid = $this->input->post('countAbsid');

			$this->model->deleteAbsList($abs_id, $cAbsid);
		}else{
			echo 'null';
		}
	}

}

/* End of file absensi.php */
/* Location: ./application/controllers/admin/absensi.php */