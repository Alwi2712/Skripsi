<div class="modal fade" id="m-qrnik-scanner">
	<div class="modal-dialog">
		<div class="modal-content" style="border-radius:0">
			<div class="modal-body">
				<div class="justify-content-center text-center">
					<div>
						<button id="btn-play-qrnik" class="btn btn-info my-2"><i class="mdi mdi-play"></i> MULAI QR</button>
						<button id="btn-upload-qrnik" class="btn btn-primary my-2"><i class="mdi mdi-upload"></i> UNGGAH QR</button>
						<button id="btn-stop-qrnik" class="btn btn-danger my-2"><i class="mdi mdi-stop"></i> MATIKAN QR</button>
					</div>
				</div>
				<div class="alert alert-success msg-qrnik-success" style="display:none;"><b> success, </b> berhasil scan QRNik.. </div>
				<div class="alert alert-danger msg-qrnik-error" style="display:none;"><b> error, </b> gagal scan QRNik! </div>
				<div class="justify-content-center text-center">
					<div class="my-2">
						<select id="qrnik-select-camera" class="form-control form-control-sm"></select>
					</div>
					<div class="text-center">
						<div style="position:relative;display:inline-block;">
							<canvas id="qrnik-scanner"></canvas>
							<div class="qr-line line-rb"></div>
							<div class="qr-line line-rt"></div>
							<div class="qr-line line-lb"></div>
							<div class="qr-line line-lt"></div>
						</div>
					</div>
					<div class="mt-2">
						<button type="button" data-dismiss="modal" class="btn btn-warning"> <i class="mdi mdi-close"></i> Tutup Popup</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>