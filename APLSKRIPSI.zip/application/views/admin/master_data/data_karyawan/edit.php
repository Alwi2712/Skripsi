<div class="page-content">
    <div class="container-fluid">
        <form kar="edit" method="POST" action="<?= base_url('admin/master_data/edit_kar/'.$kar['karyawan_id']);?>" enctype="multipart/form-data">
            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Edit Data Karyawan</h4>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="text-right">
                        <a href="<?= base_url();?>admin/master_data/data_karyawan" class="btn btn-outline-danger mb-2"> Kembali </a>
                        <button type="submit" class="btn btn-outline-primary mb-2 btn-f-kar"> Edit </button>
                    </div>
                </div>
            </div>     
            <!-- end page title -->
            <?php if ($kar['foto']=='' || is_null($kar['foto'])){ 
                $src = base_url().'assets/document/user.jpg';
            }else{
                $src = base_url().'assets/upload/karyawan/'.$kar['foto'];
            } ?>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="text-center my-3">
                                <label>
                                    <input type="hidden" name="foto-lama-edit-kar" id="foto-lama-edit-kar" value="<?= $kar['foto'];?>">
                                    <input type="file" name="foto-edit-kar" id="foto-edit-kar" style="display:none;">
                                    <img style="height:140px;width:140px;" src="<?= $src;?>" class="img-thumbnail" alt="Foto Karyawan">
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="form-group">
                                <label for="nama-edit-kar">Nama Karyawan</label>
                                <input type="text" id="nama-edit-kar" name="nama-edit-kar" placeholder="Ketikan Nama .." value="<?= $kar['nama'];?>" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="nik-edit-kar">NIK Karyawan</label>
                                <input type="text"  minlength="6" maxlength="6" id="nik-edit-kar" name="nik-edit-kar" value="<?= $kar['nik'];?>" placeholder="Ketikan Nik, min 6 Karakter, max 6 Karakter" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="jk-edit-kar">Jenis Kelamin</label>
                                <select name="jk-edit-kar" id="jk-edit-kar" class="form-control" required>
                                    <option value=""> -- pilih jenis kelamin -- </option>
                                    <option <?php if($kar['jenis_kel']=='Laki-Laki'){echo 'selected';} ?> value="Laki-Laki"> Laki-Laki </option>
                                    <option <?php if($kar['jenis_kel']=='Perempuan'){echo 'selected';} ?> value="Perempuan"> Perempuan </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="email-edit-kar">Email</label>
                                <input type="email" id="email-edit-kar" name="email-edit-kar" placeholder="Ketikan Email .." value="<?= $kar['email'];?>" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="phone-num-edit-kar">No Hp/WA</label>
                                <input type="number" id="phone-num-edit-kar" name="phone-num-edit-kar" placeholder="Ketikan No HP/WA .." value="<?= $kar['phone_number'];?>" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="pek-edit-kar">Pekerjaan Karyawan</label>
                                <select name="pek-edit-kar" id="pek-edit-kar" class="form-control" required>
                                    <option value=""> --pilih opsi pekerjaan-- </option>
                                    <?php foreach ($pek as $p): ?>
                                        <?php if ($kar['pek_id'] == $p['pek_id']){ ?>
                                            <option selected value="<?= $p['pek_id'];?>"><?= $p['pekerjaan'];?></option>
                                        <?php }else{ ?>
                                            <option value="<?= $p['pek_id'];?>"><?= $p['pekerjaan'];?></option>
                                        <?php } ?>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="pek-edit-kar">Jabatan Karyawan</label>
                                <select name="jab-edit-kar" id="jab-edit-kar" class="form-control" required>
                                    <option value=""> --pilih opsi jabatan-- </option>
                                    <?php foreach ($jab as $j): ?>
                                        <?php if ($j['jabatan_id'] == $kar['jabatan_id']){ ?>
                                            <option selected value="<?= $j['jabatan_id'];?>"><?= $j['jabatan'];?></option>
                                        <?php }else{ ?>
                                            <option value="<?= $j['jabatan_id'];?>"><?= $j['jabatan'];?></option>
                                        <?php } ?>
                                    <?php endforeach ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->