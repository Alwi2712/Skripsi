<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="page-title-box">
                    <h4 class="font-size-18">HALAMAN ABSENSI</h4>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="text-right">
                    <button id="btn-delete-ctxAbs" class="btn btn-outline-danger mb-2"><i class="mdi mdi-delete"></i> Absensi </button>
                </div>
            </div>
        </div>     
        <!-- end page title -->
        <div class="card">
            <div class="card-body">
                <table id="table-absensi" class="table table-bordered table-striped dt_responsive">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="ctx-abs-all" value=""></th>
                            <th>#</th>
                            <th>NAMA</th>
                            <th>PEKERJAAN</th>
                            <th>JABATAN</th>
                            <th>JAM</th>
                            <th>TANGGAL</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $sno=1; if (!empty($absensi)){
                            foreach ($absensi as $a){ 
                                if ($a['status']=='Masuk') {
                                    $status='<span class="badge badge-pill badge-success"> Masuk </span>';
                                } else if($a['status']=='Pulang'){
                                    $status='<span class="badge badge-pill badge-danger"> Pulang </span>';
                                }else{ $status=$a['status'];}
                            ?>
                            <tr>
                                <td><input type="checkbox" class="ctx-abs-" value="<?= $a['absensi_id'];?>"></td>
                                <td><?= $sno++; ?></td>
                                <td><?= $a['nama']; ?></td>
                                <td><?= $a['pekerjaan']; ?></td>
                                <td><?= $a['jabatan']; ?></td>
                                <td><?= date('H:i:s',strtotime($a['tgl'])); ?></td>
                                <td><?= date('d F Y',strtotime($a['tgl'])); ?></td>
                                <td><?= $status;?></td>
                            </tr>
                            <?php } } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->