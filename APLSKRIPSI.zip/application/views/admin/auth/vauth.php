<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="page-title-box">
                    <h4 class="font-size-18">HALAMAN DATA ADMIN</h4>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="text-right">
                    <a href="<?= base_url('admin/auth/add');?>" class="btn btn-outline-success mb-2"><i class="mdi mdi-plus"></i> Admin</a>
                </div>
            </div>
        </div>     
        <!-- end page title -->
        <div class="card">
            <div class="card-body">
                <table id="table-auth" class="table table-bordered table-striped dt_responsive">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>AVATAR</th>
                            <th>NAMA ADMIN</th>
                            <th>USERNAME</th>
                            <th><i class="mdi mdi-settings"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $sno=1; if (!empty($auth)){
                            foreach ($auth as $a){ ?>
                            <tr>
                                <td><?= $sno++; ?></td>
                                <td><img style="height:100px;width:100px;border-radius:50%;" src="<?= base_url('assets/upload/avatar/'.$a['avatar']);?>" alt=""></td>
                                <td><?= $a['name']; ?></td>
                                <td><?= $a['username']; ?></td>
                                <td>
                                    <a href="javascript:void(0)" authID="<?= $a['auth_id'];?>" avatar="<?= $a['avatar'];?>" class="btn btn-outline-danger btn-delete-auth"> <i class="mdi mdi-delete"></i> Delete</a>
                                </td>
                            </tr>
                            <?php } } ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->