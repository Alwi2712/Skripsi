<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row align-items-center">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <h4 class="font-size-18">HALAMAN DATA PEKERJAAN</h4>
                </div>
            </div>
        </div>     
        <!-- end page title -->
       <div class="row">
           <div class="col-md-4">
                <div class="card mb-3" id="f-pek">
                    <div class="card-header bg-success text-white">
                        <h5>Form Action</h5>
                    </div>
                    <div class="card-body">
                        <form pek method="post" action="<?= base_url();?>admin/master_data/insert_edit_pek">
                            <input type="hidden" id="data-pek-id" name="data-pek-id">
                            <div class="form-group">
                                <label for="pekerjaan-ins-data">Pekerjaan</label>
                                <input type="text" name="pekerjaan-data" id="pekerjaan-data" class="form-control" placeholder="Ketikan Pekerjaan.." required>
                            </div>
                            <button type="submit" class="btn btn-outline-success btn-block btn-pek-act"> <i class="mdi mdi-plus"></i> Pekerjaan</button>
                            <button style="display:none;" type="button" class="btn btn-outline-danger btn-block btn-reset-act"> <i class="mdi mdi-reload"></i> Reset</button>
                        </form>
                    </div>
                </div>
           </div>
           <div class="col-md-8">
               <div class="card">
                    <div class="card-body">
                        <table id="table-pekerjaan" class="table table-bordered table-striped dt_responsive">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>PEKERJAAN</th>
                                    <th>TANGGAL INPUT</th>
                                    <th><i class="mdi mdi-settings"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $sno=1; if (!empty($pekerjaan)) {
                                    foreach ($pekerjaan as $key){ ?>
                                    <tr>
                                        <td><?= $sno++; ?></td>
                                        <td><?= $key['pekerjaan']; ?></td>
                                        <td><?= date('H:i:s, d F Y',strtotime($key['create_at'])); ?></td>
                                        <td>
                                            <a href="javasript:void(0)" class="btn btn-sm btn-outline-primary btn-edit-pek" pek="<?= $key['pekerjaan'];?>" pekID="<?= $key['pek_id'];?>"><i class="mdi mdi-pencil"></i> Edit</a>
                                            <a href="javasript:void(0)" class="btn btn-sm btn-outline-danger btn-delete-pek" pekID="<?= $key['pek_id'];?>"><i class="mdi mdi-delete"></i> Hapus</a>
                                        </td>
                                    </tr>
                                <?php } } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
           </div>
       </div>
    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->