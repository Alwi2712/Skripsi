<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row align-items-center">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <h4 class="font-size-18">HALAMAN DASHBOARD</h4>

                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat bg-warning text-white">
                    <div class="card-body">
                        <div class="mb-4">
                            <div class="float-left mini-stat-img mr-4">
                                <i class="fa fa-user-lock fa-2x"></i>
                            </div>
                            <h5 class="font-size-16 text-uppercase mt-0 text-white-50"> Data Admin </h5>
                            <h4 class="font-weight-medium font-size-24"> <?= $t_admin;?> </h4>
                        </div>
                        <div class="pt-2">
                            <div class="float-right">
                                <a href="<?= base_url('admin/auth');?>" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                            </div>

                            <p class="text-white-50 mb-0 mt-1">Lihat selengkapnya.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat bg-info text-white">
                    <div class="card-body">
                        <div class="mb-4">
                            <div class="float-left mini-stat-img mr-4">
                                <!-- <i class="fas fa-users fa-2x"></i> -->
                                <i class="fas fa-user-tie fa-2x"></i>
                            </div>
                            <h5 class="font-size-16 text-uppercase mt-0 text-white-50">Data Karyawan</h5>
                            <h4 class="font-weight-medium font-size-24"> <?= $t_karyawan;?> </h4>
                        </div>
                        <div class="pt-2">
                            <div class="float-right">
                                <a href="<?= base_url('admin/master_data/data_karyawan');?>" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                            </div>

                            <p class="text-white-50 mb-0 mt-1">Lihat selengkapnya.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat bg-success text-white">
                    <div class="card-body">
                        <div class="mb-4">
                            <div class="float-left mini-stat-img mr-4">
                                <i class="fas fa-door-open fa-2x"></i>
                            </div>
                            <h5 class="font-size-16 text-uppercase mt-0 text-white-50">Absensi Masuk</h5>
                            <h4 class="font-weight-medium font-size-24"> <?= $abs_masuk;?> </h4>
                        </div>
                        <div class="pt-2">
                            <div class="float-right">
                                <a href="<?= base_url('admin/absensi');?>" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                            </div>

                            <p class="text-white-50 mb-0 mt-1">Lihat selengkapnya.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat bg-danger text-white">
                    <div class="card-body">
                        <div class="mb-4">
                            <div class="float-left mini-stat-img mr-4">
                                <i class="fas fa-door-closed fa-2x"></i>
                            </div>
                            <h5 class="font-size-16 text-uppercase mt-0 text-white-50">Absensi Pulang</h5>
                            <h4 class="font-weight-medium font-size-24"> <?= $abs_pulang;?> </h4>
                            </div>
                            <div class="pt-2">
                                <div class="float-right">
                                    <a href="<?= base_url('admin/absensi');?>" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                                </div>

                            <p class="text-white-50 mb-0 mt-1">Lihat selengkapnya.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-md-6">
                <div class="card mini-stat bg-primary text-white">
                    <div class="card-body">
                        <div class="mb-4">
                            <div class="float-left mini-stat-img mr-4">
                                <i class="fa fa-briefcase fa-2x"></i>
                            </div>
                            <h5 class="font-size-16 text-uppercase mt-0 text-white-50"> Data Pekerjaan </h5>
                            <h4 class="font-weight-medium font-size-24"> <?= $t_pekerjaan;?> </h4>
                        </div>
                        <div class="pt-2">
                            <div class="float-right">
                                <a href="<?= base_url('admin/master_data/data_pekerjaan');?>" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                            </div>

                            <p class="text-white-50 mb-0 mt-1">Lihat selengkapnya.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-md-6">
                <div class="card mini-stat bg-primary text-white">
                    <div class="card-body">
                        <div class="mb-4">
                            <div class="float-left mini-stat-img mr-4">
                                <i class="fas fa-trophy fa-2x"></i>
                            </div>
                            <h5 class="font-size-16 text-uppercase mt-0 text-white-50"> Data Jabatan </h5>
                            <h4 class="font-weight-medium font-size-24"> <?= $t_jabatan;?> </h4>
                        </div>
                        <div class="pt-2">
                            <div class="float-right">
                                <a href="<?= base_url('admin/master_data/data_jabatan');?>" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                            </div>

                            <p class="text-white-50 mb-0 mt-1">Lihat selengkapnya.</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- end row -->
    </div>
<!-- End Page-content -->