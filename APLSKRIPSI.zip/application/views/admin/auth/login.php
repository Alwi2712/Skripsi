<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Login  | ABSENSI KARYAWAN</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Dashboard Management Absensi Karyawan.." name="description" />
    <meta content="Buildercorp" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?= base_url('assets/document');?>/favicon.ico">
    <!-- Sweet Alert-->
    <link href="<?= base_url('assets');?>/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
    <!-- Bootstrap Css -->
    <link href="<?= base_url('assets');?>/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?= base_url('assets');?>/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?= base_url('assets');?>/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <style>
        .card,
        input[type="text"],
        input[type="password"],
        button.btn{
            border-radius:0;
        }
    </style>
</head>

<body>

    <div class="home-btn d-none d-sm-block">
        <a href="<?= base_url();?>" class="text-dark"><i class="fas fa-home h2"></i></a>
    </div>
    <div class="account-pages my-5 pt-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card overflow-hidden border border-primary">
                        <div class="bg-white">
                            <div class="text-primary text-center my-3">
                                <img src="<?= base_url();?>assets/document/favicon.ico" height="50" alt="logo"><h5 class="text-muted font-size-20">LOGIN <?= $this->config->item('app_name');?> !</h5>
                                <!-- <a href="index.html" class="logo logo-admin">
                                    <img src="assets/images/logo-sm.png" height="24" alt="logo">
                                </a> -->
                            </div>
                        </div>

                        <div class="card-body p-4">
                            <div class="p-3">
                                <form class="form-horizontal mt-4" id="f-logged-admin" action="<?= base_url('admin/login/process');?>">

                                    <div class="form-group">
                                        <label for="username">Username</label>
                                        <input type="text" class="form-control" id="username" placeholder="Enter username">
                                    </div>

                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" class="form-control" id="password" placeholder="Enter password">
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-12 text-right">
                                            <button class="btn btn-outline-primary w-md waves-effect waves-light" type="submit">Log In</button>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>

                    </div>

                    <div class="mt-5 text-center">
                        <p class="mb-0">© <?= $this->config->item('date_creates'); ?> ABSENSI. Crafted with <i class="mdi mdi-heart text-danger"></i> by <?= $this->config->item('author'); ?>.</p>
                    </div>


                </div>
            </div>
        </div>
    </div>

    <!-- JAVASCRIPT -->
    <script src="<?= base_url('assets');?>/libs/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets');?>/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url('assets');?>/libs/metismenu/metisMenu.min.js"></script>
    <script src="<?= base_url('assets');?>/libs/simplebar/simplebar.min.js"></script>
    <script src="<?= base_url('assets');?>/libs/node-waves/waves.min.js"></script>
    <!-- Sweet Alerts js -->
    <script src="<?= base_url('assets');?>/libs/sweetalert2/sweetalert2.min.js"></script>
    <script src="<?= base_url('assets');?>/js/app.js"></script>
    <script>
        var baseurl = '<?= base_url();?>'

        $('#f-logged-admin').submit(function(e){

            let href = $(this).attr('action');

            $.ajax({
                url:href,
                type:'post',
                data:{
                    username:$('#username').val(),
                    password:$('#password').val(),
                },
                cache:false,
                dataType:'json',
                beforeSend:function(res) {
                    $('#f-logged-admin button[type="submit"]').html('<i class="mdi mdi-loading mdi-spin"></i>').prop('disabled',true);
                }
            })
            .done(res =>{
                $('#f-logged-admin button[type="submit"]').html('Log In').removeAttr('disabled');
                if (res.data==1) {
                    setTimeout(function(){
                        window.location.href=res.redirect;
                    },2000);
                }
                Swal.fire({
                    title:res.title,
                    text:res.msg,
                    type:res.icon,
                    width:400
                });
                console.log(response);
            })
            .catch(err => {
                $('#f-logged-admin button[type="submit"]').html('Log In').removeAttr('disabled');
                console.log(err);
                Swal.fire({
                    title:'',
                    type:'error',
                    text:'gagal login coba kembali!',
                });
            });

            return false;
        })
    </script>
</body>

</html>