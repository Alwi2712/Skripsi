	<!-- note: script footer di hapus tampilan gk rapih -->
    <?= $this->config->item('footer');?>
</div>
<!-- end main content-->
</div>
<!-- END layout-wrapper -->

<!-- Modal Auth Area -->
<div class="modal fade" id="m-data-auth">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
				<button class="close" data-dismiss="modal">x</button>
				<form myauth action="<?= base_url('admin/auth/edit/'.$this->session->userdata('auth_id'));?>" method="POST" enctype="multipart/form-data">
					<div class="text-center">
					<label>
						<input type="file" auth name="avatar-edit-auth" style="display:none;">
						<?php if (empty($this->session->userdata('avatar')) || $this->session->userdata('avatar')==''){ ?>
							<img height="150" width="150" class="rounded-circle" src="<?= base_url('assets/document/user.jpg');?>" alt="change Avatar">
						<?php }else{ ?>
							<img height="150" width="150" class="rounded-circle" src="<?= base_url('assets/upload/avatar/'.$this->session->userdata('avatar'));?>" alt="change Avatar">
						<?php } ?>
					</label>
					</div>
					<div class="form-group">
						<label for="name-edit-auth">Nama Dashboard*</label>
						<input type="text" id="name-edit-auth" name="name-edit-auth" class="form-control" value="<?= $this->session->userdata('name'); ?>" placeholder="Ketikan Nama..required" required>
					</div>
					<div class="form-group">
						<label for="username-edit-auth">Username*</label>
						<input type="text" id="username-edit-auth" name="username-edit-auth" class="form-control" value="<?= $this->session->userdata('username'); ?>" placeholder="Ketikan Username untuk login..required" required>
					</div>
					<div class="form-group">
						<label for="level-edit-auth">Level Hak Akses*</label>
						<select name="level-edit-auth" id="level-edit-auth" class="form-control">
							<option value=""> --pilih Opsi level-- </option>
							<option value="admin" <?php if($this->session->userdata('level')=='admin'){echo 'selected';} ?>> Admin </option>
							<option value="karyawan" <?php if($this->session->userdata('level')=='karyawan'){echo 'selected';} ?>> karyawan </option>
						</select>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-outline-primary btn-edit-myauth"> <i class="mdi mdi-pencil"></i> Edit</button>
						<button type="button" data-dismiss="modal" class="btn btn-outline-danger"> Batal!</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="m-pwdc-auth">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
				<form myauth action="<?= base_url('admin/auth/ubahpwdauth/'.$this->session->userdata('auth_id'));?>">
					<div class="form-group">
						<label for="password-auth-lama"> Password Lama*</label>
						<input type="password" class="form-control pwdc" name="password-auth-lama" id="password-auth-lama" placeholder="Ketikan Password Lama.." required>
					</div>
					<div class="form-group">
						<label for="password-auth-baru"> Password Baru*</label>
						<input type="password" class="form-control pwdc" name="password-auth-baru" id="password-auth-baru" placeholder="Ketikan Password Lama.." required>
					</div>
					<div class="form-group">
						<label for="cpassword-auth-baru"> Password Baru Konfirmasi*</label>
						<input type="password" class="form-control pwdc" data-parsley-equalto="#password-auth-baru" id="cpassword-auth-baru" placeholder="Ketikan Password Lama.." required>
					</div>
					<div class="my-2">
						<label>
							<input showpwd type="checkbox"> Lihat Password
						</label>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary btn-edit-myauth"> <i class="mdi mdi-pencil"></i> Edit</button>
						<button type="button" data-dismiss="modal" class="btn btn-danger"> Batal</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- End Modal Auth Area -->
<!-- JAVASCRIPT -->
<script src="<?= base_url('assets');?>/libs/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets');?>/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets');?>/libs/metismenu/metisMenu.min.js"></script>
<script src="<?= base_url('assets');?>/libs/simplebar/simplebar.min.js"></script>
<script src="<?= base_url('assets');?>/libs/node-waves/waves.min.js"></script>
<!-- Sweet Alerts js -->
<script src="<?= base_url('assets');?>/libs/sweetalert2/sweetalert2.min.js"></script>
<!-- Peity chart-->
<script src="<?= base_url('assets');?>/libs/peity/jquery.peity.min.js"></script>
<!-- Required datatable js -->
<script src="<?= base_url('assets');?>/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url('assets');?>/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<!-- Buttons examples -->
<script src="<?= base_url('assets');?>/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= base_url('assets');?>/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="<?= base_url('assets');?>/libs/jszip/jszip.min.js"></script>
<script src="<?= base_url('assets');?>/libs/pdfmake/build/pdfmake.min.js"></script>
<script src="<?= base_url('assets');?>/libs/pdfmake/build/vfs_fonts.js"></script>
<script src="<?= base_url('assets');?>/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?= base_url('assets');?>/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?= base_url('assets');?>/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<!-- Responsive examples -->
<script src="<?= base_url('assets');?>/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= base_url('assets');?>/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
<!-- Plugin Js-->
<script src="<?= base_url('assets');?>/libs/chartist/chartist.min.js"></script>
<!-- Validation -->
<script src="<?= base_url('assets');?>/libs/parsleyjs/parsley.min.js"></script>
<!-- QRGenerate JS -->
<script src="<?= base_url('assets');?>/QRGenerate/qrcode.js"></script>
<!-- sheetjs -->
<script src="<?= base_url('assets');?>/libs/sheetjs/shim.min.js"></script>
<script src="<?= base_url('assets');?>/libs/sheetjs/xlsx.js"></script>
<script src="<?= base_url('assets');?>/libs/sheetjs/xlsx.full.min.js"></script>

<script src="<?= base_url('assets');?>/js/app.js"></script>

<script>
	var baseurl='<?= base_url();?>'
	var msg = $('#message-data').attr('msg')
	var icon = $('#message-data').attr('icon')
	if (msg && icon) {
		Swal.fire({
			title:'',
			width:350,
			text:msg,
			type:icon
		});
	}
	function myconfirm(){
		return Swal.fire({
				title:"Hapus data ini ?",
				text:"",
				type:"warning",
				width:350,
				showCancelButton:!0,
				confirmButtonColor:"#556ee6",
				cancelButtonColor:"#f46a6a",
				cancelButtonText:"Batal!"
			})
	}

	$('form[myauth]').parsley();

	$('input[type="checkbox"][showpwd]').on('change',function(e){
		if($(this).is(':checked')){
			$('form[myauth] .pwdc').attr('type','text');
		}else{
			$('form[myauth] .pwdc').attr('type','password');
		}
	});

	$('input[type="file"][auth]').change(function(f) {
		let source = URL.createObjectURL(f.target.files[0]);
		$(this).next('img').attr('src',source);
	});

	// all public input type file
	$('input[type="file"]').change(function(f) {
		let source = URL.createObjectURL(f.target.files[0]);
		$(this).next('img').attr('src',source);
	});

	$('form[myauth]').submit(function(e){
		
		$.ajax({
			url:$(this).attr('action'),
			type:"POST",
			data: new FormData(this),
			cache:false,
			contentType:false,
			processData:false,
			beforeSend:function(res){
				$('form[myauth] button.btn-edit-myauth').html('<i class="mdi mdi-loading mdi-spin"></i> Edit').prop('disabled',true);	
			}
		})
		.done(res => {
			$('form[myauth] button.btn-edit-myauth').html('<i class="mdi mdi-pencil"></i> Edit').removeAttr('disabled');	
			window.location.reload();
		})
		.catch(err => {
			$('form[myauth] button.btn-edit-myauth').html('<i class="mdi mdi-pencil"></i> Edit').removeAttr('disabled');	
			Swal.fire('','error edit data auth!, coba kembali.','error');
			console.log(err);
		});

		return false;
	});
</script>

</body>

</html>