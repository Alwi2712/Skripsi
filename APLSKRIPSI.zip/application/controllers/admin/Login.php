<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->view('admin/auth/login');
	}
	public function process()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$auth = $this->db->get_where('tbl_auth',['username'=>$username]);

		if ($auth->num_rows() > 0) {
			
			$auth = $auth->row_array();
			
			if (password_verify($password, $auth['password'])){

				$this->session->set_userdata([
					'auth_id' => $auth['auth_id'],
					'name' => $auth['name'],
					'username' => $auth['username'],
					'password' => $auth['password'],
					'avatar' => $auth['avatar'],
					'create_at' => $auth['create_at'],
					'level' => $auth['level']]);

				if ($this->session->userdata('level') == 'admin') {

					$this->session->set_flashdata('icon','success');
					$this->session->set_flashdata('msg','Hii! '.$this->session->userdata('name'));

					$res['data'] = 1; //< 1 = data ditemukan!, kirim kondisi response ke ajax
					$res['icon'] = 'success';
					$res['title'] = '';
					$res['msg'] = 'berhasil login...';
					$res['redirect'] = base_url().'admin/dashboard';
				}else{
					$res['data'] = 1; //< 1 = data ditemukan!, kirim kondisi response ke ajax
					$res['icon'] = 'success';
					$res['title'] = '';
					$res['msg'] = 'berhasil login...';
					$res['redirect'] = base_url();
				}
			}else{
				$res['data'] = 3; //< 3 = password salah!, kirim kondisi response ke ajax
				$res['icon'] = 'warning';
				$res['title'] = 'password salah!';
				$res['msg'] = 'periksa kembali pastikan password benar.';
			}
		}else{
			$res['data'] = 0; // 0 = username tidak ditemukan / kosong, kirim kondisi response ke ajax
			$res['icon'] = 'error';
			$res['title'] = 'data tidak ditemukan!';
			$res['msg'] = 'pastikan username & password benar!';
		}
		echo json_encode($res);
	}
	public function out()
	{
		session_destroy();
		redirect('admin/login','refresh');
	}

}

/* End of file login.php */
/* Location: ./application/controllers/admin/login.php */