(function(t) {
'use strict';t(document).on('click','.metismenu li a, .navbar-nav  li a', function(e){e.preventDefault();var halaman = t(this).attr('href');if (t(this).attr("target") == "_self") {window.location.href= halaman; return true};
if (t(this).attr("target") == "_blank") window.open(halaman, "_blank");if (halaman == "javascript: void(0);") return false;window.location.hash = halaman;t(".metismenu li, .metismenu li a").removeClass("active");t(".metismenu ul").removeClass("in");
t(".metismenu a").each(function() {var pageUrl = window.location.hash.substr(1);if (t(this).attr("href") == pageUrl) {t(this).addClass("active");t(this).parent().addClass("mm-active");
t(this).parent().parent().addClass("mm-show");t(this).parent().parent().prev().addClass("mm-active"); 
t(this).parent().parent().parent().addClass("mm-active");t(this).parent().parent().parent().parent().addClass("mm-show");t(this).parent().parent().parent().parent().parent().addClass("mm-active");}});
t(".navbar-nav a").removeClass("active");t(".navbar-nav li").removeClass("active");t(".navbar-nav a").each(function () {
var pageUrl = window.location.hash.substr(1);if (t(this).attr('href') == pageUrl) {t(this).addClass("active");t(this).parent().addClass("active");t(this).parent().parent().addClass("active");
t(this).parent().parent().parent().addClass("active");t(this).parent().parent().parent().parent().addClass("active");t(this).parent().parent().parent().parent().parent().addClass("active");}});my_ajax(halaman);});
function my_ajax(halaman) { if(halaman === "/masuk"||halaman === ""){ document.title = "MASUK | ABSENSI KARYAWAN";}else{var title = halaman.replace('/','');var title1 = title.replace("-", " ");document.title = title1.toUpperCase() + " | ABSENSI KARYAWAN";}t.ajax({
url: baseurl + halaman,cache: false,dataType: "html",type: "GET",success: function(data){t("#result-main").empty();t("#result-main").html(data);window.location.hash = halaman;t(window).scrollTop(0);}});}
t(document).ready(function() { var path = window.location.hash.substr(1).replace('/','');if (path == "pulang") {menu_active('pulang');my_ajax("/pulang");} else if (path == "masuk") {
menu_active('masuk');my_ajax("/masuk");} else if (path == "absensi") {menu_active('absensi');my_ajax("/absensi");} else {menu_active('masuk');my_ajax("/masuk");}});
function menu_active(el) {t(".metismenu li, .metismenu li a").removeClass("active");t(".metismenu ul").removeClass("in");t('.metismenu li.'+el).addClass('mm-active');t('.metismenu li a.'+el).addClass('active');t('.metismenu').addClass('mm-show');}}($));