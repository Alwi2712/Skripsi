<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
	License app
*/
$config['date_creates'] = '2022';
$config['author'] = 'Arby Saepul Ryzen';
$config['app_name'] = 'ABSENSI';
$config['footer'] = '<footer class="footer"><div class="container-fluid"><div class="row"><div class="col-12"><p class="mb-0">© 2022 ABSENSI. Crafted with <i class="mdi mdi-heart text-danger"></i> by Arby Saepul Ryzen.</p></div></div></div></footer>';