<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Admin {

	public function index()
	{
		$x['t_admin'] = $this->db->get('tbl_auth')->num_rows();
		$x['t_karyawan'] = $this->db->get('tbl_karyawan')->num_rows();
		$x['t_pekerjaan'] = $this->db->get('tbl_pekerjaan')->num_rows();
		$x['t_jabatan'] = $this->db->get('tbl_jabatan')->num_rows();
		$x['abs_masuk'] = $this->db->get_where('tbl_absensi',['status'=>'Masuk'])->num_rows();
		$x['abs_pulang'] = $this->db->get_where('tbl_absensi',['status'=>'Pulang'])->num_rows();
		$this->load->view('admin/layout/head-sidebar');
		$this->load->view('admin/dashboard/vdashboard',$x);
		$this->load->view('admin/layout/footer');
	}

}

/* End of file dashboard.php */
/* Location: ./application/controllers/admin/dashboard.php */